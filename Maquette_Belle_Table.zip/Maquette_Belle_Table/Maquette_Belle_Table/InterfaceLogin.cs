﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquette_Belle_Table
{
    public partial class InterfaceLogin : Form
    {
        public InterfaceLogin()
        {
            InitializeComponent();
        }

        private void linkLabelMDP_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            panelMDPO.Visible = true;
        }

        private void labelMDPEm_Click(object sender, EventArgs e)
        {

        }

        private void buttonAnnu_Click(object sender, EventArgs e)
        {
            panelMDPO.Visible = false;
        }

        private void textBoxMDPre_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelMDPO_Click(object sender, EventArgs e)
        {

        }

        private void labelFermeture_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panelMDPO_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonInterAd_Click(object sender, EventArgs e)
        {
            new InterfaceAd().Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new InterfaceGes().Show();
            this.Hide();
        }

        private void InterfaceLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
