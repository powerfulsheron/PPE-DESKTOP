﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquette_Belle_Table
{
    public partial class InterfaceAd : Form
    {
        public InterfaceAd()
        {
            InitializeComponent();
        }

        private void tableLayoutPanelPt3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelFermeture_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelUti_Click(object sender, EventArgs e)
        {
            panelUti.Show();
            panelHC.Hide();
            panelCMDP.Hide();
            labelUti.ForeColor = Color.Gold;
            labelHC.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.White;
            panelUtilisateur.Visible = true;
            panelHistoriqueC.Visible = false;
            panelChangerMDP.Visible = false;
        }

        private void labelHC_Click(object sender, EventArgs e)
        {
            panelUti.Hide();
            panelHC.Show();
            panelCMDP.Hide();
            labelUti.ForeColor = Color.White;
            labelHC.ForeColor = Color.Gold;
            labelCMDP.ForeColor = Color.White;
            panelUtilisateur.Visible = false;
            panelHistoriqueC.Visible = true;
            panelChangerMDP.Visible = false;
        }

        private void labelCMDP_Click(object sender, EventArgs e)
        {
            panelUti.Hide();
            panelHC.Hide();
            panelCMDP.Show();
            labelUti.ForeColor = Color.White;
            labelHC.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.Gold;
            panelUtilisateur.Visible = false;
            panelHistoriqueC.Visible = false;
            panelChangerMDP.Visible = true;
        }

        private void buttonAddUti_Click(object sender, EventArgs e)
        {
            new Popup_AddModUser().Show();
        }

        private void buttonModUti_Click(object sender, EventArgs e)
        {
            new Popup_AddModUser().Show();
        }
    }
}
