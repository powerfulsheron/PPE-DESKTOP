﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquette_Belle_Table
{
    public partial class PopNouveauRDV : Form
    {
        public PopNouveauRDV()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PopNouveauRDV_Load(object sender, EventArgs e)
        {

        }

        private void panelTitre_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonAnul_Click(object sender, EventArgs e)
        {

        }

        private void buttonVal_Click(object sender, EventArgs e)
        {

        }

        private void textBoxIC_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelIC_Click(object sender, EventArgs e)
        {

        }

        private void labelVille_Click(object sender, EventArgs e)
        {

        }

        private void textBoxVille_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelCP_Click(object sender, EventArgs e)
        {

        }

        private void textBoxCp_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelRue_Click(object sender, EventArgs e)
        {

        }

        private void textBoxRue_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxClient_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelClient_Click(object sender, EventArgs e)
        {

        }
    }
}
