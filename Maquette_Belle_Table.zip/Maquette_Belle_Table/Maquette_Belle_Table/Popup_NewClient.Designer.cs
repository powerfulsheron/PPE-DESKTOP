﻿namespace Maquette_Belle_Table
{
    partial class Popup_NewClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.buttonAnul = new System.Windows.Forms.Button();
            this.buttonVal = new System.Windows.Forms.Button();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.labelNom = new System.Windows.Forms.Label();
            this.groupBoxAP = new System.Windows.Forms.GroupBox();
            this.textBoxIC = new System.Windows.Forms.TextBox();
            this.labelIC = new System.Windows.Forms.Label();
            this.textBoxVille = new System.Windows.Forms.TextBox();
            this.textBoxCp = new System.Windows.Forms.TextBox();
            this.textBoxRue = new System.Windows.Forms.TextBox();
            this.labelRue = new System.Windows.Forms.Label();
            this.labelCP = new System.Windows.Forms.Label();
            this.labelVille = new System.Windows.Forms.Label();
            this.labelQParticulier = new System.Windows.Forms.Label();
            this.groupBoxQParticulier = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.labelPrénom = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labelTel = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxAS = new System.Windows.Forms.GroupBox();
            this.textBoxICAS = new System.Windows.Forms.TextBox();
            this.labelICAS = new System.Windows.Forms.Label();
            this.textBoxVAS = new System.Windows.Forms.TextBox();
            this.textBoxCPAS = new System.Windows.Forms.TextBox();
            this.textBoxRAS = new System.Windows.Forms.TextBox();
            this.labelRAS = new System.Windows.Forms.Label();
            this.labelCPAS = new System.Windows.Forms.Label();
            this.labelVAS = new System.Windows.Forms.Label();
            this.textBoxDS = new System.Windows.Forms.TextBox();
            this.labelDS = new System.Windows.Forms.Label();
            this.comboBoxTS = new System.Windows.Forms.ComboBox();
            this.labelTS = new System.Windows.Forms.Label();
            this.panelMenu.SuspendLayout();
            this.panelTitre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.groupBoxAP.SuspendLayout();
            this.groupBoxQParticulier.SuspendLayout();
            this.groupBoxAS.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelMenu.Controls.Add(this.panelTitre);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1125, 33);
            this.panelMenu.TabIndex = 11;
            // 
            // panelTitre
            // 
            this.panelTitre.Controls.Add(this.label1);
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(0, 0);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(1125, 33);
            this.panelTitre.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MidnightBlue;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(1091, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "X";
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(1429, 0);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 22);
            this.labelFermeture.TabIndex = 2;
            this.labelFermeture.Text = "X";
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(40, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(65, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "GEPEV";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table.Properties.Resources.table;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(32, 27);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(1124, 33);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 620);
            this.panelBorderRight.TabIndex = 10;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 33);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 620);
            this.panelBordeLeft.TabIndex = 12;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(1, 652);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(1123, 1);
            this.panelBorderBottom.TabIndex = 13;
            // 
            // buttonAnul
            // 
            this.buttonAnul.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnul.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnul.ForeColor = System.Drawing.Color.Gold;
            this.buttonAnul.Location = new System.Drawing.Point(98, 609);
            this.buttonAnul.Name = "buttonAnul";
            this.buttonAnul.Size = new System.Drawing.Size(100, 34);
            this.buttonAnul.TabIndex = 23;
            this.buttonAnul.Text = "Annuler";
            this.buttonAnul.UseVisualStyleBackColor = false;
            // 
            // buttonVal
            // 
            this.buttonVal.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonVal.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVal.ForeColor = System.Drawing.Color.Gold;
            this.buttonVal.Location = new System.Drawing.Point(428, 609);
            this.buttonVal.Name = "buttonVal";
            this.buttonVal.Size = new System.Drawing.Size(100, 34);
            this.buttonVal.TabIndex = 24;
            this.buttonVal.Text = "Valider";
            this.buttonVal.UseVisualStyleBackColor = false;
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(98, 60);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(189, 27);
            this.textBoxNom.TabIndex = 22;
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.BackColor = System.Drawing.Color.Transparent;
            this.labelNom.Location = new System.Drawing.Point(37, 63);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(55, 21);
            this.labelNom.TabIndex = 20;
            this.labelNom.Text = "Nom :";
            // 
            // groupBoxAP
            // 
            this.groupBoxAP.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxAP.Controls.Add(this.textBoxIC);
            this.groupBoxAP.Controls.Add(this.labelIC);
            this.groupBoxAP.Controls.Add(this.textBoxVille);
            this.groupBoxAP.Controls.Add(this.textBoxCp);
            this.groupBoxAP.Controls.Add(this.textBoxRue);
            this.groupBoxAP.Controls.Add(this.labelRue);
            this.groupBoxAP.Controls.Add(this.labelCP);
            this.groupBoxAP.Controls.Add(this.labelVille);
            this.groupBoxAP.Location = new System.Drawing.Point(41, 219);
            this.groupBoxAP.Name = "groupBoxAP";
            this.groupBoxAP.Size = new System.Drawing.Size(534, 302);
            this.groupBoxAP.TabIndex = 21;
            this.groupBoxAP.TabStop = false;
            this.groupBoxAP.Text = "Adresse personnelle";
            // 
            // textBoxIC
            // 
            this.textBoxIC.Location = new System.Drawing.Point(16, 203);
            this.textBoxIC.Multiline = true;
            this.textBoxIC.Name = "textBoxIC";
            this.textBoxIC.Size = new System.Drawing.Size(512, 93);
            this.textBoxIC.TabIndex = 15;
            // 
            // labelIC
            // 
            this.labelIC.AutoSize = true;
            this.labelIC.Location = new System.Drawing.Point(12, 179);
            this.labelIC.Name = "labelIC";
            this.labelIC.Size = new System.Drawing.Size(194, 21);
            this.labelIC.TabIndex = 14;
            this.labelIC.Text = "Infos complémentaires :";
            // 
            // textBoxVille
            // 
            this.textBoxVille.Location = new System.Drawing.Point(76, 142);
            this.textBoxVille.Name = "textBoxVille";
            this.textBoxVille.Size = new System.Drawing.Size(310, 27);
            this.textBoxVille.TabIndex = 13;
            // 
            // textBoxCp
            // 
            this.textBoxCp.Location = new System.Drawing.Point(126, 96);
            this.textBoxCp.Name = "textBoxCp";
            this.textBoxCp.Size = new System.Drawing.Size(153, 27);
            this.textBoxCp.TabIndex = 12;
            // 
            // textBoxRue
            // 
            this.textBoxRue.Location = new System.Drawing.Point(76, 39);
            this.textBoxRue.Name = "textBoxRue";
            this.textBoxRue.Size = new System.Drawing.Size(452, 27);
            this.textBoxRue.TabIndex = 11;
            // 
            // labelRue
            // 
            this.labelRue.AutoSize = true;
            this.labelRue.Location = new System.Drawing.Point(12, 42);
            this.labelRue.Name = "labelRue";
            this.labelRue.Size = new System.Drawing.Size(48, 21);
            this.labelRue.TabIndex = 5;
            this.labelRue.Text = "Rue :";
            // 
            // labelCP
            // 
            this.labelCP.AutoSize = true;
            this.labelCP.Location = new System.Drawing.Point(12, 99);
            this.labelCP.Name = "labelCP";
            this.labelCP.Size = new System.Drawing.Size(114, 21);
            this.labelCP.TabIndex = 4;
            this.labelCP.Text = "Code postal :";
            // 
            // labelVille
            // 
            this.labelVille.AutoSize = true;
            this.labelVille.Location = new System.Drawing.Point(12, 145);
            this.labelVille.Name = "labelVille";
            this.labelVille.Size = new System.Drawing.Size(48, 21);
            this.labelVille.TabIndex = 3;
            this.labelVille.Text = "Ville :";
            // 
            // labelQParticulier
            // 
            this.labelQParticulier.AutoSize = true;
            this.labelQParticulier.Location = new System.Drawing.Point(6, 34);
            this.labelQParticulier.Name = "labelQParticulier";
            this.labelQParticulier.Size = new System.Drawing.Size(240, 21);
            this.labelQParticulier.TabIndex = 5;
            this.labelQParticulier.Text = "Le client est t\'il un particulier ?";
            // 
            // groupBoxQParticulier
            // 
            this.groupBoxQParticulier.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxQParticulier.Controls.Add(this.labelQParticulier);
            this.groupBoxQParticulier.Location = new System.Drawing.Point(41, 538);
            this.groupBoxQParticulier.Name = "groupBoxQParticulier";
            this.groupBoxQParticulier.Size = new System.Drawing.Size(534, 65);
            this.groupBoxQParticulier.TabIndex = 25;
            this.groupBoxQParticulier.TabStop = false;
            this.groupBoxQParticulier.Text = "Particulier";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(405, 60);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(170, 27);
            this.textBox1.TabIndex = 27;
            // 
            // labelPrénom
            // 
            this.labelPrénom.AutoSize = true;
            this.labelPrénom.BackColor = System.Drawing.Color.Transparent;
            this.labelPrénom.Location = new System.Drawing.Point(322, 63);
            this.labelPrénom.Name = "labelPrénom";
            this.labelPrénom.Size = new System.Drawing.Size(77, 21);
            this.labelPrénom.TabIndex = 26;
            this.labelPrénom.Text = "Prénom :";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(98, 116);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(189, 27);
            this.textBox2.TabIndex = 29;
            // 
            // labelTel
            // 
            this.labelTel.AutoSize = true;
            this.labelTel.BackColor = System.Drawing.Color.Transparent;
            this.labelTel.Location = new System.Drawing.Point(37, 119);
            this.labelTel.Name = "labelTel";
            this.labelTel.Size = new System.Drawing.Size(39, 21);
            this.labelTel.TabIndex = 28;
            this.labelTel.Text = "Tél :";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(98, 166);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(420, 27);
            this.textBox3.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(37, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 21);
            this.label4.TabIndex = 30;
            this.label4.Text = "Email :";
            // 
            // groupBoxAS
            // 
            this.groupBoxAS.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxAS.Controls.Add(this.comboBoxTS);
            this.groupBoxAS.Controls.Add(this.labelTS);
            this.groupBoxAS.Controls.Add(this.textBoxDS);
            this.groupBoxAS.Controls.Add(this.labelDS);
            this.groupBoxAS.Controls.Add(this.textBoxICAS);
            this.groupBoxAS.Controls.Add(this.labelICAS);
            this.groupBoxAS.Controls.Add(this.textBoxVAS);
            this.groupBoxAS.Controls.Add(this.textBoxCPAS);
            this.groupBoxAS.Controls.Add(this.textBoxRAS);
            this.groupBoxAS.Controls.Add(this.labelRAS);
            this.groupBoxAS.Controls.Add(this.labelCPAS);
            this.groupBoxAS.Controls.Add(this.labelVAS);
            this.groupBoxAS.Location = new System.Drawing.Point(581, 60);
            this.groupBoxAS.Name = "groupBoxAS";
            this.groupBoxAS.Size = new System.Drawing.Size(532, 461);
            this.groupBoxAS.TabIndex = 22;
            this.groupBoxAS.TabStop = false;
            this.groupBoxAS.Text = "Adresse structure";
            // 
            // textBoxICAS
            // 
            this.textBoxICAS.Location = new System.Drawing.Point(6, 362);
            this.textBoxICAS.Multiline = true;
            this.textBoxICAS.Name = "textBoxICAS";
            this.textBoxICAS.Size = new System.Drawing.Size(512, 93);
            this.textBoxICAS.TabIndex = 15;
            // 
            // labelICAS
            // 
            this.labelICAS.AutoSize = true;
            this.labelICAS.Location = new System.Drawing.Point(2, 338);
            this.labelICAS.Name = "labelICAS";
            this.labelICAS.Size = new System.Drawing.Size(194, 21);
            this.labelICAS.TabIndex = 14;
            this.labelICAS.Text = "Infos complémentaires :";
            // 
            // textBoxVAS
            // 
            this.textBoxVAS.Location = new System.Drawing.Point(66, 301);
            this.textBoxVAS.Name = "textBoxVAS";
            this.textBoxVAS.Size = new System.Drawing.Size(310, 27);
            this.textBoxVAS.TabIndex = 13;
            // 
            // textBoxCPAS
            // 
            this.textBoxCPAS.Location = new System.Drawing.Point(116, 255);
            this.textBoxCPAS.Name = "textBoxCPAS";
            this.textBoxCPAS.Size = new System.Drawing.Size(153, 27);
            this.textBoxCPAS.TabIndex = 12;
            // 
            // textBoxRAS
            // 
            this.textBoxRAS.Location = new System.Drawing.Point(66, 198);
            this.textBoxRAS.Name = "textBoxRAS";
            this.textBoxRAS.Size = new System.Drawing.Size(452, 27);
            this.textBoxRAS.TabIndex = 11;
            // 
            // labelRAS
            // 
            this.labelRAS.AutoSize = true;
            this.labelRAS.Location = new System.Drawing.Point(2, 201);
            this.labelRAS.Name = "labelRAS";
            this.labelRAS.Size = new System.Drawing.Size(48, 21);
            this.labelRAS.TabIndex = 5;
            this.labelRAS.Text = "Rue :";
            // 
            // labelCPAS
            // 
            this.labelCPAS.AutoSize = true;
            this.labelCPAS.Location = new System.Drawing.Point(2, 258);
            this.labelCPAS.Name = "labelCPAS";
            this.labelCPAS.Size = new System.Drawing.Size(114, 21);
            this.labelCPAS.TabIndex = 4;
            this.labelCPAS.Text = "Code postal :";
            // 
            // labelVAS
            // 
            this.labelVAS.AutoSize = true;
            this.labelVAS.Location = new System.Drawing.Point(2, 304);
            this.labelVAS.Name = "labelVAS";
            this.labelVAS.Size = new System.Drawing.Size(48, 21);
            this.labelVAS.TabIndex = 3;
            this.labelVAS.Text = "Ville :";
            // 
            // textBoxDS
            // 
            this.textBoxDS.Location = new System.Drawing.Point(6, 151);
            this.textBoxDS.Name = "textBoxDS";
            this.textBoxDS.Size = new System.Drawing.Size(512, 27);
            this.textBoxDS.TabIndex = 17;
            // 
            // labelDS
            // 
            this.labelDS.AutoSize = true;
            this.labelDS.Location = new System.Drawing.Point(6, 122);
            this.labelDS.Name = "labelDS";
            this.labelDS.Size = new System.Drawing.Size(186, 21);
            this.labelDS.TabIndex = 16;
            this.labelDS.Text = "Dénomination sociale :";
            // 
            // comboBoxTS
            // 
            this.comboBoxTS.FormattingEnabled = true;
            this.comboBoxTS.Items.AddRange(new object[] {
            "Commercial",
            "Gestionnaire",
            "Administrateur"});
            this.comboBoxTS.Location = new System.Drawing.Point(147, 34);
            this.comboBoxTS.Name = "comboBoxTS";
            this.comboBoxTS.Size = new System.Drawing.Size(199, 29);
            this.comboBoxTS.TabIndex = 21;
            // 
            // labelTS
            // 
            this.labelTS.AutoSize = true;
            this.labelTS.BackColor = System.Drawing.Color.Transparent;
            this.labelTS.Location = new System.Drawing.Point(12, 37);
            this.labelTS.Name = "labelTS";
            this.labelTS.Size = new System.Drawing.Size(129, 21);
            this.labelTS.TabIndex = 20;
            this.labelTS.Text = "Type structure :";
            // 
            // Popup_NewClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.ClientSize = new System.Drawing.Size(1125, 653);
            this.Controls.Add(this.groupBoxAS);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.labelTel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelPrénom);
            this.Controls.Add(this.groupBoxQParticulier);
            this.Controls.Add(this.buttonAnul);
            this.Controls.Add(this.buttonVal);
            this.Controls.Add(this.textBoxNom);
            this.Controls.Add(this.labelNom);
            this.Controls.Add(this.groupBoxAP);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.panelMenu);
            this.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Popup_NewClient";
            this.Text = "Popup_NewClient";
            this.panelMenu.ResumeLayout(false);
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.groupBoxAP.ResumeLayout(false);
            this.groupBoxAP.PerformLayout();
            this.groupBoxQParticulier.ResumeLayout(false);
            this.groupBoxQParticulier.PerformLayout();
            this.groupBoxAS.ResumeLayout(false);
            this.groupBoxAS.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Button buttonAnul;
        private System.Windows.Forms.Button buttonVal;
        private System.Windows.Forms.TextBox textBoxNom;
        private System.Windows.Forms.Label labelNom;
        private System.Windows.Forms.GroupBox groupBoxAP;
        private System.Windows.Forms.TextBox textBoxIC;
        private System.Windows.Forms.Label labelIC;
        private System.Windows.Forms.TextBox textBoxVille;
        private System.Windows.Forms.TextBox textBoxCp;
        private System.Windows.Forms.TextBox textBoxRue;
        private System.Windows.Forms.Label labelRue;
        private System.Windows.Forms.Label labelCP;
        private System.Windows.Forms.Label labelVille;
        private System.Windows.Forms.Label labelQParticulier;
        private System.Windows.Forms.GroupBox groupBoxQParticulier;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label labelPrénom;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label labelTel;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBoxAS;
        private System.Windows.Forms.TextBox textBoxDS;
        private System.Windows.Forms.Label labelDS;
        private System.Windows.Forms.TextBox textBoxICAS;
        private System.Windows.Forms.Label labelICAS;
        private System.Windows.Forms.TextBox textBoxVAS;
        private System.Windows.Forms.TextBox textBoxCPAS;
        private System.Windows.Forms.TextBox textBoxRAS;
        private System.Windows.Forms.Label labelRAS;
        private System.Windows.Forms.Label labelCPAS;
        private System.Windows.Forms.Label labelVAS;
        private System.Windows.Forms.ComboBox comboBoxTS;
        private System.Windows.Forms.Label labelTS;
    }
}