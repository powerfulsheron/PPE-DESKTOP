﻿namespace Maquette_Belle_Table
{
    partial class InterfaceLogin
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InterfaceLogin));
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.labelFermeture = new System.Windows.Forms.Label();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxMDP = new System.Windows.Forms.TextBox();
            this.linkLabelMDP = new System.Windows.Forms.LinkLabel();
            this.buttonConnexion = new System.Windows.Forms.Button();
            this.labelErrorMDP = new System.Windows.Forms.Label();
            this.labelErrorId = new System.Windows.Forms.Label();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelMDPO = new System.Windows.Forms.Panel();
            this.labelMDPO = new System.Windows.Forms.Label();
            this.textBoxMDPNom = new System.Windows.Forms.TextBox();
            this.textBoxMDPre = new System.Windows.Forms.TextBox();
            this.textBoxMDPEm = new System.Windows.Forms.TextBox();
            this.labelMDPNom = new System.Windows.Forms.Label();
            this.labelMDPre = new System.Windows.Forms.Label();
            this.labelMDPEm = new System.Windows.Forms.Label();
            this.buttonAnnu = new System.Windows.Forms.Button();
            this.buttonVal = new System.Windows.Forms.Button();
            this.buttonInterAd = new System.Windows.Forms.Button();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderTop = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelMDPO.SuspendLayout();
            this.SuspendLayout();
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.WhiteSmoke;
            this.labelFermeture.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Location = new System.Drawing.Point(288, 9);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 21);
            this.labelFermeture.TabIndex = 1;
            this.labelFermeture.Text = "X";
            this.labelFermeture.Click += new System.EventHandler(this.labelFermeture_Click);
            // 
            // textBoxId
            // 
            this.textBoxId.HideSelection = false;
            this.textBoxId.Location = new System.Drawing.Point(70, 116);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(188, 30);
            this.textBoxId.TabIndex = 2;
            this.textBoxId.Text = "Identifiant";
            this.textBoxId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxMDP
            // 
            this.textBoxMDP.HideSelection = false;
            this.textBoxMDP.Location = new System.Drawing.Point(70, 161);
            this.textBoxMDP.Name = "textBoxMDP";
            this.textBoxMDP.PasswordChar = '*';
            this.textBoxMDP.Size = new System.Drawing.Size(188, 30);
            this.textBoxMDP.TabIndex = 3;
            this.textBoxMDP.Text = "Mot de passe";
            this.textBoxMDP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // linkLabelMDP
            // 
            this.linkLabelMDP.AutoSize = true;
            this.linkLabelMDP.Font = new System.Drawing.Font("Century Gothic", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelMDP.Location = new System.Drawing.Point(166, 200);
            this.linkLabelMDP.Name = "linkLabelMDP";
            this.linkLabelMDP.Size = new System.Drawing.Size(161, 19);
            this.linkLabelMDP.TabIndex = 4;
            this.linkLabelMDP.TabStop = true;
            this.linkLabelMDP.Text = "Mot de passe oublié ?";
            this.linkLabelMDP.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelMDP_LinkClicked);
            // 
            // buttonConnexion
            // 
            this.buttonConnexion.BackColor = System.Drawing.Color.Gold;
            this.buttonConnexion.Location = new System.Drawing.Point(70, 233);
            this.buttonConnexion.Name = "buttonConnexion";
            this.buttonConnexion.Size = new System.Drawing.Size(188, 36);
            this.buttonConnexion.TabIndex = 5;
            this.buttonConnexion.Text = "Connexion";
            this.buttonConnexion.UseVisualStyleBackColor = false;
            // 
            // labelErrorMDP
            // 
            this.labelErrorMDP.AutoSize = true;
            this.labelErrorMDP.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErrorMDP.Location = new System.Drawing.Point(13, 292);
            this.labelErrorMDP.Name = "labelErrorMDP";
            this.labelErrorMDP.Size = new System.Drawing.Size(189, 21);
            this.labelErrorMDP.TabIndex = 6;
            this.labelErrorMDP.Text = "Mot de passe incorrect";
            this.labelErrorMDP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // labelErrorId
            // 
            this.labelErrorId.AutoSize = true;
            this.labelErrorId.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelErrorId.Location = new System.Drawing.Point(17, 292);
            this.labelErrorId.Name = "labelErrorId";
            this.labelErrorId.Size = new System.Drawing.Size(166, 21);
            this.labelErrorId.TabIndex = 7;
            this.labelErrorId.Text = "Identifiant incorrect";
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Controls.Add(this.labelFermeture);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(1, 1);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(311, 82);
            this.panelLogo.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Maquette_Belle_Table.Properties.Resources.Logo_BT2;
            this.pictureBox1.Location = new System.Drawing.Point(64, 12);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(204, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panelMDPO
            // 
            this.panelMDPO.Controls.Add(this.buttonVal);
            this.panelMDPO.Controls.Add(this.buttonAnnu);
            this.panelMDPO.Controls.Add(this.labelMDPEm);
            this.panelMDPO.Controls.Add(this.labelMDPre);
            this.panelMDPO.Controls.Add(this.labelMDPNom);
            this.panelMDPO.Controls.Add(this.textBoxMDPEm);
            this.panelMDPO.Controls.Add(this.textBoxMDPre);
            this.panelMDPO.Controls.Add(this.textBoxMDPNom);
            this.panelMDPO.Controls.Add(this.labelMDPO);
            this.panelMDPO.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMDPO.Location = new System.Drawing.Point(1, 83);
            this.panelMDPO.Name = "panelMDPO";
            this.panelMDPO.Size = new System.Drawing.Size(311, 267);
            this.panelMDPO.TabIndex = 9;
            this.panelMDPO.Visible = false;
            this.panelMDPO.Paint += new System.Windows.Forms.PaintEventHandler(this.panelMDPO_Paint);
            // 
            // labelMDPO
            // 
            this.labelMDPO.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.labelMDPO.AutoSize = true;
            this.labelMDPO.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMDPO.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelMDPO.Location = new System.Drawing.Point(97, 9);
            this.labelMDPO.Name = "labelMDPO";
            this.labelMDPO.Size = new System.Drawing.Size(188, 21);
            this.labelMDPO.TabIndex = 0;
            this.labelMDPO.Text = "Mot de passe oublié";
            this.labelMDPO.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelMDPO.Click += new System.EventHandler(this.labelMDPO_Click);
            // 
            // textBoxMDPNom
            // 
            this.textBoxMDPNom.Location = new System.Drawing.Point(80, 42);
            this.textBoxMDPNom.Name = "textBoxMDPNom";
            this.textBoxMDPNom.Size = new System.Drawing.Size(188, 30);
            this.textBoxMDPNom.TabIndex = 1;
            // 
            // textBoxMDPre
            // 
            this.textBoxMDPre.Location = new System.Drawing.Point(80, 79);
            this.textBoxMDPre.Name = "textBoxMDPre";
            this.textBoxMDPre.Size = new System.Drawing.Size(188, 30);
            this.textBoxMDPre.TabIndex = 2;
            this.textBoxMDPre.TextChanged += new System.EventHandler(this.textBoxMDPre_TextChanged);
            // 
            // textBoxMDPEm
            // 
            this.textBoxMDPEm.Location = new System.Drawing.Point(80, 118);
            this.textBoxMDPEm.Name = "textBoxMDPEm";
            this.textBoxMDPEm.Size = new System.Drawing.Size(205, 30);
            this.textBoxMDPEm.TabIndex = 3;
            // 
            // labelMDPNom
            // 
            this.labelMDPNom.AutoSize = true;
            this.labelMDPNom.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelMDPNom.Location = new System.Drawing.Point(15, 45);
            this.labelMDPNom.Name = "labelMDPNom";
            this.labelMDPNom.Size = new System.Drawing.Size(52, 21);
            this.labelMDPNom.TabIndex = 4;
            this.labelMDPNom.Text = "Nom";
            // 
            // labelMDPre
            // 
            this.labelMDPre.AutoSize = true;
            this.labelMDPre.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelMDPre.Location = new System.Drawing.Point(12, 81);
            this.labelMDPre.Name = "labelMDPre";
            this.labelMDPre.Size = new System.Drawing.Size(78, 21);
            this.labelMDPre.TabIndex = 5;
            this.labelMDPre.Text = "Prénom";
            // 
            // labelMDPEm
            // 
            this.labelMDPEm.AutoSize = true;
            this.labelMDPEm.ForeColor = System.Drawing.Color.MidnightBlue;
            this.labelMDPEm.Location = new System.Drawing.Point(12, 121);
            this.labelMDPEm.Name = "labelMDPEm";
            this.labelMDPEm.Size = new System.Drawing.Size(55, 21);
            this.labelMDPEm.TabIndex = 6;
            this.labelMDPEm.Text = "Email";
            this.labelMDPEm.Click += new System.EventHandler(this.labelMDPEm_Click);
            // 
            // buttonAnnu
            // 
            this.buttonAnnu.BackColor = System.Drawing.Color.Gold;
            this.buttonAnnu.Font = new System.Drawing.Font("Century Gothic", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnnu.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnnu.Location = new System.Drawing.Point(16, 178);
            this.buttonAnnu.Name = "buttonAnnu";
            this.buttonAnnu.Size = new System.Drawing.Size(76, 38);
            this.buttonAnnu.TabIndex = 7;
            this.buttonAnnu.Text = "Annuler";
            this.buttonAnnu.UseVisualStyleBackColor = false;
            this.buttonAnnu.Click += new System.EventHandler(this.buttonAnnu_Click);
            // 
            // buttonVal
            // 
            this.buttonVal.BackColor = System.Drawing.Color.Gold;
            this.buttonVal.Font = new System.Drawing.Font("Century Gothic", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVal.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonVal.Location = new System.Drawing.Point(225, 178);
            this.buttonVal.Name = "buttonVal";
            this.buttonVal.Size = new System.Drawing.Size(76, 38);
            this.buttonVal.TabIndex = 8;
            this.buttonVal.Text = "Valider";
            this.buttonVal.UseVisualStyleBackColor = false;
            // 
            // buttonInterAd
            // 
            this.buttonInterAd.BackColor = System.Drawing.Color.Gold;
            this.buttonInterAd.Location = new System.Drawing.Point(64, 316);
            this.buttonInterAd.Name = "buttonInterAd";
            this.buttonInterAd.Size = new System.Drawing.Size(75, 23);
            this.buttonInterAd.TabIndex = 9;
            this.buttonInterAd.Text = "Inter Ad";
            this.buttonInterAd.UseVisualStyleBackColor = false;
            this.buttonInterAd.Click += new System.EventHandler(this.buttonInterAd_Click);
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(312, 0);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 351);
            this.panelBorderRight.TabIndex = 10;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(0, 350);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(312, 1);
            this.panelBorderBottom.TabIndex = 11;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 0);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 350);
            this.panelBordeLeft.TabIndex = 12;
            // 
            // panelBorderTop
            // 
            this.panelBorderTop.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBorderTop.Location = new System.Drawing.Point(1, 0);
            this.panelBorderTop.Name = "panelBorderTop";
            this.panelBorderTop.Size = new System.Drawing.Size(311, 1);
            this.panelBorderTop.TabIndex = 13;
            // 
            // InterfaceLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(313, 351);
            this.Controls.Add(this.panelMDPO);
            this.Controls.Add(this.panelLogo);
            this.Controls.Add(this.panelBorderTop);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.labelErrorId);
            this.Controls.Add(this.labelErrorMDP);
            this.Controls.Add(this.buttonConnexion);
            this.Controls.Add(this.buttonInterAd);
            this.Controls.Add(this.linkLabelMDP);
            this.Controls.Add(this.textBoxMDP);
            this.Controls.Add(this.textBoxId);
            this.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "InterfaceLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Maquette Belle Table";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelMDPO.ResumeLayout(false);
            this.panelMDPO.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxMDP;
        private System.Windows.Forms.LinkLabel linkLabelMDP;
        private System.Windows.Forms.Button buttonConnexion;
        private System.Windows.Forms.Label labelErrorMDP;
        private System.Windows.Forms.Label labelErrorId;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelMDPO;
        private System.Windows.Forms.Label labelMDPEm;
        private System.Windows.Forms.Label labelMDPre;
        private System.Windows.Forms.Label labelMDPNom;
        private System.Windows.Forms.TextBox textBoxMDPEm;
        private System.Windows.Forms.TextBox textBoxMDPre;
        private System.Windows.Forms.TextBox textBoxMDPNom;
        private System.Windows.Forms.Label labelMDPO;
        private System.Windows.Forms.Button buttonVal;
        private System.Windows.Forms.Button buttonAnnu;
        private System.Windows.Forms.Button buttonInterAd;
        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderTop;
    }
}

