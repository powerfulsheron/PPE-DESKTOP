﻿namespace Maquette_Belle_Table
{
    partial class InterfaceGes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.tableLayoutPanelPt3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3Trait = new System.Windows.Forms.TableLayoutPanel();
            this.panelCMDP = new System.Windows.Forms.Panel();
            this.panelMails = new System.Windows.Forms.Panel();
            this.panelPF = new System.Windows.Forms.Panel();
            this.panelPlanC = new System.Windows.Forms.Panel();
            this.panelPlan = new System.Windows.Forms.Panel();
            this.tableLayoutPanelNomMe = new System.Windows.Forms.TableLayoutPanel();
            this.labelCMDP = new System.Windows.Forms.Label();
            this.labelMails = new System.Windows.Forms.Label();
            this.labelPF = new System.Windows.Forms.Label();
            this.labelPlaC = new System.Windows.Forms.Label();
            this.labelPla = new System.Windows.Forms.Label();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.labelClose = new System.Windows.Forms.Label();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.panelPlanning = new System.Windows.Forms.Panel();
            this.groupBoxPJS = new System.Windows.Forms.GroupBox();
            this.listViewPlan = new System.Windows.Forms.ListView();
            this.buttonNRDV = new System.Windows.Forms.Button();
            this.monthCalendarPlan = new System.Windows.Forms.MonthCalendar();
            this.panelPlanningC = new System.Windows.Forms.Panel();
            this.groupBoxPJSPC = new System.Windows.Forms.GroupBox();
            this.listViewPJSPC = new System.Windows.Forms.ListView();
            this.buttonNPC = new System.Windows.Forms.Button();
            this.monthCalendarPlanC = new System.Windows.Forms.MonthCalendar();
            this.panelPortefeuille = new System.Windows.Forms.Panel();
            this.dataGridViewPortefeuille = new System.Windows.Forms.DataGridView();
            this.buttonEnvoiMail = new System.Windows.Forms.Button();
            this.buttonModCli = new System.Windows.Forms.Button();
            this.buttonAddCli = new System.Windows.Forms.Button();
            this.panelMail = new System.Windows.Forms.Panel();
            this.buttonOuvrirEmail = new System.Windows.Forms.Button();
            this.buttonEnvoiEmail = new System.Windows.Forms.Button();
            this.dataGridViewMail = new System.Windows.Forms.DataGridView();
            this.panelChangerMDP = new System.Windows.Forms.Panel();
            this.buttonValCM = new System.Windows.Forms.Button();
            this.textBoxNoMDP = new System.Windows.Forms.TextBox();
            this.labelNoMDP = new System.Windows.Forms.Label();
            this.labelLogC = new System.Windows.Forms.Label();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.panelMenu.SuspendLayout();
            this.tableLayoutPanelPt3.SuspendLayout();
            this.tableLayoutPanel3Trait.SuspendLayout();
            this.tableLayoutPanelNomMe.SuspendLayout();
            this.panelTitre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.panelPlanning.SuspendLayout();
            this.groupBoxPJS.SuspendLayout();
            this.panelPlanningC.SuspendLayout();
            this.groupBoxPJSPC.SuspendLayout();
            this.panelPortefeuille.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPortefeuille)).BeginInit();
            this.panelMail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMail)).BeginInit();
            this.panelChangerMDP.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(1187, 0);
            this.panelBorderRight.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 650);
            this.panelBorderRight.TabIndex = 7;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(0, 649);
            this.panelBorderBottom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(1187, 1);
            this.panelBorderBottom.TabIndex = 8;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 0);
            this.panelBordeLeft.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 649);
            this.panelBordeLeft.TabIndex = 9;
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelMenu.Controls.Add(this.tableLayoutPanelPt3);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(1, 0);
            this.panelMenu.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1186, 77);
            this.panelMenu.TabIndex = 10;
            // 
            // tableLayoutPanelPt3
            // 
            this.tableLayoutPanelPt3.ColumnCount = 1;
            this.tableLayoutPanelPt3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelPt3.Controls.Add(this.tableLayoutPanel3Trait, 0, 2);
            this.tableLayoutPanelPt3.Controls.Add(this.tableLayoutPanelNomMe, 0, 1);
            this.tableLayoutPanelPt3.Controls.Add(this.panelTitre, 0, 0);
            this.tableLayoutPanelPt3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanelPt3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelPt3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanelPt3.Name = "tableLayoutPanelPt3";
            this.tableLayoutPanelPt3.RowCount = 3;
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.78161F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.74074F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.45679F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 22F));
            this.tableLayoutPanelPt3.Size = new System.Drawing.Size(1186, 77);
            this.tableLayoutPanelPt3.TabIndex = 0;
            // 
            // tableLayoutPanel3Trait
            // 
            this.tableLayoutPanel3Trait.ColumnCount = 5;
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3Trait.Controls.Add(this.panelCMDP, 0, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelMails, 0, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelPF, 2, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelPlanC, 1, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelPlan, 0, 0);
            this.tableLayoutPanel3Trait.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3Trait.Location = new System.Drawing.Point(4, 62);
            this.tableLayoutPanel3Trait.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanel3Trait.Name = "tableLayoutPanel3Trait";
            this.tableLayoutPanel3Trait.RowCount = 1;
            this.tableLayoutPanel3Trait.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3Trait.Size = new System.Drawing.Size(1178, 12);
            this.tableLayoutPanel3Trait.TabIndex = 0;
            // 
            // panelCMDP
            // 
            this.panelCMDP.BackColor = System.Drawing.Color.Gold;
            this.panelCMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCMDP.Location = new System.Drawing.Point(474, 3);
            this.panelCMDP.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelCMDP.Name = "panelCMDP";
            this.panelCMDP.Size = new System.Drawing.Size(227, 6);
            this.panelCMDP.TabIndex = 4;
            this.panelCMDP.Visible = false;
            // 
            // panelMails
            // 
            this.panelMails.BackColor = System.Drawing.Color.Gold;
            this.panelMails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMails.Location = new System.Drawing.Point(239, 3);
            this.panelMails.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelMails.Name = "panelMails";
            this.panelMails.Size = new System.Drawing.Size(227, 6);
            this.panelMails.TabIndex = 3;
            this.panelMails.Visible = false;
            // 
            // panelPF
            // 
            this.panelPF.BackColor = System.Drawing.Color.Gold;
            this.panelPF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPF.Location = new System.Drawing.Point(944, 3);
            this.panelPF.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPF.Name = "panelPF";
            this.panelPF.Size = new System.Drawing.Size(230, 6);
            this.panelPF.TabIndex = 2;
            this.panelPF.Visible = false;
            // 
            // panelPlanC
            // 
            this.panelPlanC.BackColor = System.Drawing.Color.Gold;
            this.panelPlanC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlanC.Location = new System.Drawing.Point(709, 3);
            this.panelPlanC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPlanC.Name = "panelPlanC";
            this.panelPlanC.Size = new System.Drawing.Size(227, 6);
            this.panelPlanC.TabIndex = 1;
            this.panelPlanC.Visible = false;
            // 
            // panelPlan
            // 
            this.panelPlan.BackColor = System.Drawing.Color.Gold;
            this.panelPlan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlan.Location = new System.Drawing.Point(4, 3);
            this.panelPlan.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPlan.Name = "panelPlan";
            this.panelPlan.Size = new System.Drawing.Size(227, 6);
            this.panelPlan.TabIndex = 0;
            this.panelPlan.Visible = false;
            // 
            // tableLayoutPanelNomMe
            // 
            this.tableLayoutPanelNomMe.ColumnCount = 5;
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanelNomMe.Controls.Add(this.labelCMDP, 4, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelMails, 3, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelPF, 2, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelPlaC, 1, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelPla, 0, 0);
            this.tableLayoutPanelNomMe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelNomMe.Location = new System.Drawing.Point(4, 31);
            this.tableLayoutPanelNomMe.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tableLayoutPanelNomMe.Name = "tableLayoutPanelNomMe";
            this.tableLayoutPanelNomMe.RowCount = 1;
            this.tableLayoutPanelNomMe.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelNomMe.Size = new System.Drawing.Size(1178, 25);
            this.tableLayoutPanelNomMe.TabIndex = 1;
            // 
            // labelCMDP
            // 
            this.labelCMDP.AutoSize = true;
            this.labelCMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCMDP.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCMDP.ForeColor = System.Drawing.Color.Gold;
            this.labelCMDP.Location = new System.Drawing.Point(944, 0);
            this.labelCMDP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCMDP.Name = "labelCMDP";
            this.labelCMDP.Size = new System.Drawing.Size(230, 25);
            this.labelCMDP.TabIndex = 4;
            this.labelCMDP.Text = "Changer mot de passe";
            this.labelCMDP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCMDP.Click += new System.EventHandler(this.labelCMDP_Click);
            // 
            // labelMails
            // 
            this.labelMails.AutoSize = true;
            this.labelMails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelMails.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMails.ForeColor = System.Drawing.Color.Gold;
            this.labelMails.Location = new System.Drawing.Point(709, 0);
            this.labelMails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelMails.Name = "labelMails";
            this.labelMails.Size = new System.Drawing.Size(227, 25);
            this.labelMails.TabIndex = 3;
            this.labelMails.Text = "Mails";
            this.labelMails.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelMails.Click += new System.EventHandler(this.labelMails_Click);
            // 
            // labelPF
            // 
            this.labelPF.AutoSize = true;
            this.labelPF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPF.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPF.ForeColor = System.Drawing.Color.Gold;
            this.labelPF.Location = new System.Drawing.Point(474, 0);
            this.labelPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPF.Name = "labelPF";
            this.labelPF.Size = new System.Drawing.Size(227, 25);
            this.labelPF.TabIndex = 2;
            this.labelPF.Text = "Portefeuille";
            this.labelPF.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelPF.Click += new System.EventHandler(this.labelPF_Click);
            // 
            // labelPlaC
            // 
            this.labelPlaC.AutoSize = true;
            this.labelPlaC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPlaC.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPlaC.ForeColor = System.Drawing.Color.Gold;
            this.labelPlaC.Location = new System.Drawing.Point(239, 0);
            this.labelPlaC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPlaC.Name = "labelPlaC";
            this.labelPlaC.Size = new System.Drawing.Size(227, 25);
            this.labelPlaC.TabIndex = 1;
            this.labelPlaC.Text = "Plannification Congés";
            this.labelPlaC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelPlaC.Click += new System.EventHandler(this.labelPlaC_Click);
            // 
            // labelPla
            // 
            this.labelPla.AutoSize = true;
            this.labelPla.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelPla.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPla.ForeColor = System.Drawing.Color.Gold;
            this.labelPla.Location = new System.Drawing.Point(4, 0);
            this.labelPla.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPla.Name = "labelPla";
            this.labelPla.Size = new System.Drawing.Size(227, 25);
            this.labelPla.TabIndex = 0;
            this.labelPla.Text = "Planning";
            this.labelPla.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelPla.Click += new System.EventHandler(this.labelPla_Click);
            // 
            // panelTitre
            // 
            this.panelTitre.Controls.Add(this.labelClose);
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(4, 3);
            this.panelTitre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(1178, 22);
            this.panelTitre.TabIndex = 2;
            // 
            // labelClose
            // 
            this.labelClose.AutoSize = true;
            this.labelClose.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelClose.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelClose.ForeColor = System.Drawing.Color.Gold;
            this.labelClose.Location = new System.Drawing.Point(1156, 3);
            this.labelClose.Name = "labelClose";
            this.labelClose.Size = new System.Drawing.Size(22, 22);
            this.labelClose.TabIndex = 3;
            this.labelClose.Text = "X";
            this.labelClose.Click += new System.EventHandler(this.labelClose_Click);
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(1414, 0);
            this.labelFermeture.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 22);
            this.labelFermeture.TabIndex = 2;
            this.labelFermeture.Text = "X";
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(39, 0);
            this.labelBT.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(65, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "GEPEV";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table.Properties.Resources.table1;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(32, 28);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // panelPlanning
            // 
            this.panelPlanning.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelPlanning.Controls.Add(this.groupBoxPJS);
            this.panelPlanning.Controls.Add(this.buttonNRDV);
            this.panelPlanning.Controls.Add(this.monthCalendarPlan);
            this.panelPlanning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlanning.Location = new System.Drawing.Point(1, 77);
            this.panelPlanning.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPlanning.Name = "panelPlanning";
            this.panelPlanning.Size = new System.Drawing.Size(1186, 572);
            this.panelPlanning.TabIndex = 11;
            this.panelPlanning.Visible = false;
            this.panelPlanning.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPlanning_Paint);
            // 
            // groupBoxPJS
            // 
            this.groupBoxPJS.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBoxPJS.Controls.Add(this.listViewPlan);
            this.groupBoxPJS.Location = new System.Drawing.Point(771, 117);
            this.groupBoxPJS.Name = "groupBoxPJS";
            this.groupBoxPJS.Size = new System.Drawing.Size(330, 426);
            this.groupBoxPJS.TabIndex = 2;
            this.groupBoxPJS.TabStop = false;
            this.groupBoxPJS.Text = "Planning du Jour sélectionné";
            this.groupBoxPJS.Enter += new System.EventHandler(this.groupBoxPJS_Enter);
            // 
            // listViewPlan
            // 
            this.listViewPlan.Location = new System.Drawing.Point(6, 70);
            this.listViewPlan.Name = "listViewPlan";
            this.listViewPlan.Size = new System.Drawing.Size(318, 350);
            this.listViewPlan.TabIndex = 0;
            this.listViewPlan.UseCompatibleStateImageBehavior = false;
            // 
            // buttonNRDV
            // 
            this.buttonNRDV.BackColor = System.Drawing.Color.Gold;
            this.buttonNRDV.Location = new System.Drawing.Point(821, 51);
            this.buttonNRDV.Name = "buttonNRDV";
            this.buttonNRDV.Size = new System.Drawing.Size(230, 34);
            this.buttonNRDV.TabIndex = 1;
            this.buttonNRDV.Text = "Nouveau Rendez-vous";
            this.buttonNRDV.UseVisualStyleBackColor = false;
            this.buttonNRDV.Click += new System.EventHandler(this.buttonNRDV_Click);
            // 
            // monthCalendarPlan
            // 
            this.monthCalendarPlan.CalendarDimensions = new System.Drawing.Size(2, 2);
            this.monthCalendarPlan.Location = new System.Drawing.Point(62, 63);
            this.monthCalendarPlan.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
            this.monthCalendarPlan.MaximumSize = new System.Drawing.Size(943, 552);
            this.monthCalendarPlan.MinimumSize = new System.Drawing.Size(313, 252);
            this.monthCalendarPlan.Name = "monthCalendarPlan";
            this.monthCalendarPlan.ShowToday = false;
            this.monthCalendarPlan.ShowTodayCircle = false;
            this.monthCalendarPlan.TabIndex = 0;
            // 
            // panelPlanningC
            // 
            this.panelPlanningC.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelPlanningC.Controls.Add(this.groupBoxPJSPC);
            this.panelPlanningC.Controls.Add(this.buttonNPC);
            this.panelPlanningC.Controls.Add(this.monthCalendarPlanC);
            this.panelPlanningC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlanningC.Location = new System.Drawing.Point(1, 77);
            this.panelPlanningC.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPlanningC.Name = "panelPlanningC";
            this.panelPlanningC.Size = new System.Drawing.Size(1186, 572);
            this.panelPlanningC.TabIndex = 12;
            this.panelPlanningC.Visible = false;
            // 
            // groupBoxPJSPC
            // 
            this.groupBoxPJSPC.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBoxPJSPC.Controls.Add(this.listViewPJSPC);
            this.groupBoxPJSPC.Location = new System.Drawing.Point(771, 117);
            this.groupBoxPJSPC.Name = "groupBoxPJSPC";
            this.groupBoxPJSPC.Size = new System.Drawing.Size(330, 426);
            this.groupBoxPJSPC.TabIndex = 2;
            this.groupBoxPJSPC.TabStop = false;
            this.groupBoxPJSPC.Text = "Planning du Jour sélectionné";
            // 
            // listViewPJSPC
            // 
            this.listViewPJSPC.Location = new System.Drawing.Point(6, 70);
            this.listViewPJSPC.Name = "listViewPJSPC";
            this.listViewPJSPC.Size = new System.Drawing.Size(318, 350);
            this.listViewPJSPC.TabIndex = 0;
            this.listViewPJSPC.UseCompatibleStateImageBehavior = false;
            // 
            // buttonNPC
            // 
            this.buttonNPC.BackColor = System.Drawing.Color.Gold;
            this.buttonNPC.Location = new System.Drawing.Point(796, 51);
            this.buttonNPC.Name = "buttonNPC";
            this.buttonNPC.Size = new System.Drawing.Size(280, 34);
            this.buttonNPC.TabIndex = 1;
            this.buttonNPC.Text = "Nouvelle période de congés";
            this.buttonNPC.UseVisualStyleBackColor = false;
            // 
            // monthCalendarPlanC
            // 
            this.monthCalendarPlanC.CalendarDimensions = new System.Drawing.Size(2, 2);
            this.monthCalendarPlanC.Location = new System.Drawing.Point(62, 63);
            this.monthCalendarPlanC.Margin = new System.Windows.Forms.Padding(11, 10, 11, 10);
            this.monthCalendarPlanC.MaximumSize = new System.Drawing.Size(943, 552);
            this.monthCalendarPlanC.MinimumSize = new System.Drawing.Size(313, 252);
            this.monthCalendarPlanC.Name = "monthCalendarPlanC";
            this.monthCalendarPlanC.ShowToday = false;
            this.monthCalendarPlanC.ShowTodayCircle = false;
            this.monthCalendarPlanC.TabIndex = 0;
            // 
            // panelPortefeuille
            // 
            this.panelPortefeuille.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelPortefeuille.Controls.Add(this.dataGridViewPortefeuille);
            this.panelPortefeuille.Controls.Add(this.buttonEnvoiMail);
            this.panelPortefeuille.Controls.Add(this.buttonModCli);
            this.panelPortefeuille.Controls.Add(this.buttonAddCli);
            this.panelPortefeuille.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPortefeuille.Location = new System.Drawing.Point(1, 77);
            this.panelPortefeuille.Name = "panelPortefeuille";
            this.panelPortefeuille.Size = new System.Drawing.Size(1186, 572);
            this.panelPortefeuille.TabIndex = 3;
            this.panelPortefeuille.Visible = false;
            // 
            // dataGridViewPortefeuille
            // 
            this.dataGridViewPortefeuille.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPortefeuille.Location = new System.Drawing.Point(12, 117);
            this.dataGridViewPortefeuille.Name = "dataGridViewPortefeuille";
            this.dataGridViewPortefeuille.RowTemplate.Height = 28;
            this.dataGridViewPortefeuille.Size = new System.Drawing.Size(1152, 382);
            this.dataGridViewPortefeuille.TabIndex = 4;
            // 
            // buttonEnvoiMail
            // 
            this.buttonEnvoiMail.BackColor = System.Drawing.Color.Gold;
            this.buttonEnvoiMail.Location = new System.Drawing.Point(934, 37);
            this.buttonEnvoiMail.Name = "buttonEnvoiMail";
            this.buttonEnvoiMail.Size = new System.Drawing.Size(230, 34);
            this.buttonEnvoiMail.TabIndex = 3;
            this.buttonEnvoiMail.Text = "Envoyer un mail";
            this.buttonEnvoiMail.UseVisualStyleBackColor = false;
            // 
            // buttonModCli
            // 
            this.buttonModCli.BackColor = System.Drawing.Color.Gold;
            this.buttonModCli.Location = new System.Drawing.Point(265, 37);
            this.buttonModCli.Name = "buttonModCli";
            this.buttonModCli.Size = new System.Drawing.Size(230, 34);
            this.buttonModCli.TabIndex = 2;
            this.buttonModCli.Text = "Modifier un client";
            this.buttonModCli.UseVisualStyleBackColor = false;
            // 
            // buttonAddCli
            // 
            this.buttonAddCli.BackColor = System.Drawing.Color.Gold;
            this.buttonAddCli.Location = new System.Drawing.Point(12, 37);
            this.buttonAddCli.Name = "buttonAddCli";
            this.buttonAddCli.Size = new System.Drawing.Size(230, 34);
            this.buttonAddCli.TabIndex = 1;
            this.buttonAddCli.Text = "Ajouter un client";
            this.buttonAddCli.UseVisualStyleBackColor = false;
            // 
            // panelMail
            // 
            this.panelMail.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelMail.Controls.Add(this.buttonOuvrirEmail);
            this.panelMail.Controls.Add(this.buttonEnvoiEmail);
            this.panelMail.Controls.Add(this.dataGridViewMail);
            this.panelMail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMail.Location = new System.Drawing.Point(1, 77);
            this.panelMail.Name = "panelMail";
            this.panelMail.Size = new System.Drawing.Size(1186, 572);
            this.panelMail.TabIndex = 5;
            this.panelMail.Visible = false;
            // 
            // buttonOuvrirEmail
            // 
            this.buttonOuvrirEmail.BackColor = System.Drawing.Color.Gold;
            this.buttonOuvrirEmail.Location = new System.Drawing.Point(945, 101);
            this.buttonOuvrirEmail.Name = "buttonOuvrirEmail";
            this.buttonOuvrirEmail.Size = new System.Drawing.Size(230, 34);
            this.buttonOuvrirEmail.TabIndex = 2;
            this.buttonOuvrirEmail.Text = "Ouvrir le mail";
            this.buttonOuvrirEmail.UseVisualStyleBackColor = false;
            // 
            // buttonEnvoiEmail
            // 
            this.buttonEnvoiEmail.BackColor = System.Drawing.Color.Gold;
            this.buttonEnvoiEmail.Location = new System.Drawing.Point(945, 37);
            this.buttonEnvoiEmail.Name = "buttonEnvoiEmail";
            this.buttonEnvoiEmail.Size = new System.Drawing.Size(230, 34);
            this.buttonEnvoiEmail.TabIndex = 1;
            this.buttonEnvoiEmail.Text = "Envoyer un Email";
            this.buttonEnvoiEmail.UseVisualStyleBackColor = false;
            // 
            // dataGridViewMail
            // 
            this.dataGridViewMail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMail.Location = new System.Drawing.Point(19, 37);
            this.dataGridViewMail.Name = "dataGridViewMail";
            this.dataGridViewMail.RowTemplate.Height = 28;
            this.dataGridViewMail.Size = new System.Drawing.Size(909, 515);
            this.dataGridViewMail.TabIndex = 0;
            // 
            // panelChangerMDP
            // 
            this.panelChangerMDP.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelChangerMDP.Controls.Add(this.buttonValCM);
            this.panelChangerMDP.Controls.Add(this.textBoxNoMDP);
            this.panelChangerMDP.Controls.Add(this.labelNoMDP);
            this.panelChangerMDP.Controls.Add(this.labelLogC);
            this.panelChangerMDP.Controls.Add(this.textBoxLog);
            this.panelChangerMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChangerMDP.Location = new System.Drawing.Point(1, 77);
            this.panelChangerMDP.Name = "panelChangerMDP";
            this.panelChangerMDP.Size = new System.Drawing.Size(1186, 572);
            this.panelChangerMDP.TabIndex = 8;
            this.panelChangerMDP.Visible = false;
            // 
            // buttonValCM
            // 
            this.buttonValCM.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonValCM.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValCM.ForeColor = System.Drawing.Color.Gold;
            this.buttonValCM.Location = new System.Drawing.Point(547, 344);
            this.buttonValCM.Name = "buttonValCM";
            this.buttonValCM.Size = new System.Drawing.Size(90, 32);
            this.buttonValCM.TabIndex = 16;
            this.buttonValCM.Text = "Valider";
            this.buttonValCM.UseVisualStyleBackColor = false;
            // 
            // textBoxNoMDP
            // 
            this.textBoxNoMDP.Location = new System.Drawing.Point(468, 274);
            this.textBoxNoMDP.Name = "textBoxNoMDP";
            this.textBoxNoMDP.Size = new System.Drawing.Size(248, 30);
            this.textBoxNoMDP.TabIndex = 3;
            // 
            // labelNoMDP
            // 
            this.labelNoMDP.AutoSize = true;
            this.labelNoMDP.BackColor = System.Drawing.Color.Transparent;
            this.labelNoMDP.Location = new System.Drawing.Point(492, 216);
            this.labelNoMDP.Name = "labelNoMDP";
            this.labelNoMDP.Size = new System.Drawing.Size(226, 22);
            this.labelNoMDP.TabIndex = 1;
            this.labelNoMDP.Text = "Nouveau mot de passe :";
            // 
            // labelLogC
            // 
            this.labelLogC.AutoSize = true;
            this.labelLogC.BackColor = System.Drawing.Color.Transparent;
            this.labelLogC.Location = new System.Drawing.Point(563, 81);
            this.labelLogC.Name = "labelLogC";
            this.labelLogC.Size = new System.Drawing.Size(67, 22);
            this.labelLogC.TabIndex = 0;
            this.labelLogC.Text = "Login :";
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(484, 161);
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(216, 30);
            this.textBoxLog.TabIndex = 2;
            // 
            // InterfaceGes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.ClientSize = new System.Drawing.Size(1188, 650);
            this.Controls.Add(this.panelChangerMDP);
            this.Controls.Add(this.panelMail);
            this.Controls.Add(this.panelPortefeuille);
            this.Controls.Add(this.panelPlanningC);
            this.Controls.Add(this.panelPlanning);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBorderRight);
            this.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "InterfaceGes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InterfaceGes";
            this.panelMenu.ResumeLayout(false);
            this.tableLayoutPanelPt3.ResumeLayout(false);
            this.tableLayoutPanel3Trait.ResumeLayout(false);
            this.tableLayoutPanelNomMe.ResumeLayout(false);
            this.tableLayoutPanelNomMe.PerformLayout();
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.panelPlanning.ResumeLayout(false);
            this.groupBoxPJS.ResumeLayout(false);
            this.panelPlanningC.ResumeLayout(false);
            this.groupBoxPJSPC.ResumeLayout(false);
            this.panelPortefeuille.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPortefeuille)).EndInit();
            this.panelMail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMail)).EndInit();
            this.panelChangerMDP.ResumeLayout(false);
            this.panelChangerMDP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPt3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3Trait;
        private System.Windows.Forms.Panel panelPF;
        private System.Windows.Forms.Panel panelPlanC;
        private System.Windows.Forms.Panel panelPlan;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelNomMe;
        private System.Windows.Forms.Label labelPF;
        private System.Windows.Forms.Label labelPlaC;
        private System.Windows.Forms.Label labelPla;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.Label labelMails;
        private System.Windows.Forms.Label labelCMDP;
        private System.Windows.Forms.Panel panelCMDP;
        private System.Windows.Forms.Panel panelMails;
        private System.Windows.Forms.Panel panelPlanning;
        private System.Windows.Forms.MonthCalendar monthCalendarPlan;
        private System.Windows.Forms.Button buttonNRDV;
        private System.Windows.Forms.GroupBox groupBoxPJS;
        private System.Windows.Forms.ListView listViewPlan;
        private System.Windows.Forms.Panel panelPlanningC;
        private System.Windows.Forms.GroupBox groupBoxPJSPC;
        private System.Windows.Forms.ListView listViewPJSPC;
        private System.Windows.Forms.Button buttonNPC;
        private System.Windows.Forms.MonthCalendar monthCalendarPlanC;
        private System.Windows.Forms.Panel panelPortefeuille;
        private System.Windows.Forms.DataGridView dataGridViewPortefeuille;
        private System.Windows.Forms.Button buttonEnvoiMail;
        private System.Windows.Forms.Button buttonModCli;
        private System.Windows.Forms.Button buttonAddCli;
        private System.Windows.Forms.Panel panelMail;
        private System.Windows.Forms.DataGridView dataGridViewMail;
        private System.Windows.Forms.Button buttonOuvrirEmail;
        private System.Windows.Forms.Button buttonEnvoiEmail;
        private System.Windows.Forms.Panel panelChangerMDP;
        private System.Windows.Forms.Button buttonValCM;
        private System.Windows.Forms.TextBox textBoxNoMDP;
        private System.Windows.Forms.Label labelNoMDP;
        private System.Windows.Forms.Label labelLogC;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Label labelClose;
    }
}