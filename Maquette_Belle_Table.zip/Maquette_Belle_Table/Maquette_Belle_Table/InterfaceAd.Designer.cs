﻿namespace Maquette_Belle_Table
{
    partial class InterfaceAd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InterfaceAd));
            this.panelMenu = new System.Windows.Forms.Panel();
            this.tableLayoutPanelPt3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3Trait = new System.Windows.Forms.TableLayoutPanel();
            this.panelCMDP = new System.Windows.Forms.Panel();
            this.panelHC = new System.Windows.Forms.Panel();
            this.panelUti = new System.Windows.Forms.Panel();
            this.tableLayoutPanelNomMe = new System.Windows.Forms.TableLayoutPanel();
            this.labelCMDP = new System.Windows.Forms.Label();
            this.labelHC = new System.Windows.Forms.Label();
            this.labelUti = new System.Windows.Forms.Label();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.panelUtilisateur = new System.Windows.Forms.Panel();
            this.dataGridViewInterUti = new System.Windows.Forms.DataGridView();
            this.buttonSuppUti = new System.Windows.Forms.Button();
            this.buttonModUti = new System.Windows.Forms.Button();
            this.buttonAddUti = new System.Windows.Forms.Button();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.panelHistoriqueC = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panelChangerMDP = new System.Windows.Forms.Panel();
            this.labelLogC = new System.Windows.Forms.Label();
            this.labelNoMDP = new System.Windows.Forms.Label();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.textBoxNoMDP = new System.Windows.Forms.TextBox();
            this.buttonValCM = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.tableLayoutPanelPt3.SuspendLayout();
            this.tableLayoutPanel3Trait.SuspendLayout();
            this.tableLayoutPanelNomMe.SuspendLayout();
            this.panelTitre.SuspendLayout();
            this.panelUtilisateur.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInterUti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.panelHistoriqueC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panelChangerMDP.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelMenu.Controls.Add(this.tableLayoutPanelPt3);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1188, 70);
            this.panelMenu.TabIndex = 0;
            // 
            // tableLayoutPanelPt3
            // 
            this.tableLayoutPanelPt3.ColumnCount = 1;
            this.tableLayoutPanelPt3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelPt3.Controls.Add(this.tableLayoutPanel3Trait, 0, 2);
            this.tableLayoutPanelPt3.Controls.Add(this.tableLayoutPanelNomMe, 0, 1);
            this.tableLayoutPanelPt3.Controls.Add(this.panelTitre, 0, 0);
            this.tableLayoutPanelPt3.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanelPt3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelPt3.Name = "tableLayoutPanelPt3";
            this.tableLayoutPanelPt3.RowCount = 3;
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.78161F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40.74074F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.45679F));
            this.tableLayoutPanelPt3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelPt3.Size = new System.Drawing.Size(1188, 70);
            this.tableLayoutPanelPt3.TabIndex = 0;
            this.tableLayoutPanelPt3.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanelPt3_Paint);
            // 
            // tableLayoutPanel3Trait
            // 
            this.tableLayoutPanel3Trait.ColumnCount = 3;
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3Trait.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3Trait.Controls.Add(this.panelCMDP, 2, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelHC, 1, 0);
            this.tableLayoutPanel3Trait.Controls.Add(this.panelUti, 0, 0);
            this.tableLayoutPanel3Trait.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3Trait.Location = new System.Drawing.Point(3, 56);
            this.tableLayoutPanel3Trait.Name = "tableLayoutPanel3Trait";
            this.tableLayoutPanel3Trait.RowCount = 1;
            this.tableLayoutPanel3Trait.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3Trait.Size = new System.Drawing.Size(1182, 11);
            this.tableLayoutPanel3Trait.TabIndex = 0;
            // 
            // panelCMDP
            // 
            this.panelCMDP.BackColor = System.Drawing.Color.Gold;
            this.panelCMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCMDP.Location = new System.Drawing.Point(791, 3);
            this.panelCMDP.Name = "panelCMDP";
            this.panelCMDP.Size = new System.Drawing.Size(388, 5);
            this.panelCMDP.TabIndex = 2;
            this.panelCMDP.Visible = false;
            // 
            // panelHC
            // 
            this.panelHC.BackColor = System.Drawing.Color.Gold;
            this.panelHC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHC.Location = new System.Drawing.Point(397, 3);
            this.panelHC.Name = "panelHC";
            this.panelHC.Size = new System.Drawing.Size(388, 5);
            this.panelHC.TabIndex = 1;
            this.panelHC.Visible = false;
            // 
            // panelUti
            // 
            this.panelUti.BackColor = System.Drawing.Color.Gold;
            this.panelUti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUti.Location = new System.Drawing.Point(3, 3);
            this.panelUti.Name = "panelUti";
            this.panelUti.Size = new System.Drawing.Size(388, 5);
            this.panelUti.TabIndex = 0;
            this.panelUti.Visible = false;
            // 
            // tableLayoutPanelNomMe
            // 
            this.tableLayoutPanelNomMe.ColumnCount = 3;
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelNomMe.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelNomMe.Controls.Add(this.labelCMDP, 2, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelHC, 1, 0);
            this.tableLayoutPanelNomMe.Controls.Add(this.labelUti, 0, 0);
            this.tableLayoutPanelNomMe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelNomMe.Location = new System.Drawing.Point(3, 28);
            this.tableLayoutPanelNomMe.Name = "tableLayoutPanelNomMe";
            this.tableLayoutPanelNomMe.RowCount = 1;
            this.tableLayoutPanelNomMe.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelNomMe.Size = new System.Drawing.Size(1182, 22);
            this.tableLayoutPanelNomMe.TabIndex = 1;
            // 
            // labelCMDP
            // 
            this.labelCMDP.AutoSize = true;
            this.labelCMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelCMDP.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCMDP.ForeColor = System.Drawing.Color.Gold;
            this.labelCMDP.Location = new System.Drawing.Point(791, 0);
            this.labelCMDP.Name = "labelCMDP";
            this.labelCMDP.Size = new System.Drawing.Size(388, 22);
            this.labelCMDP.TabIndex = 2;
            this.labelCMDP.Text = "Changer mot de pass";
            this.labelCMDP.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelCMDP.Click += new System.EventHandler(this.labelCMDP_Click);
            // 
            // labelHC
            // 
            this.labelHC.AutoSize = true;
            this.labelHC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelHC.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHC.ForeColor = System.Drawing.Color.Gold;
            this.labelHC.Location = new System.Drawing.Point(397, 0);
            this.labelHC.Name = "labelHC";
            this.labelHC.Size = new System.Drawing.Size(388, 22);
            this.labelHC.TabIndex = 1;
            this.labelHC.Text = "Historique Connexion";
            this.labelHC.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelHC.Click += new System.EventHandler(this.labelHC_Click);
            // 
            // labelUti
            // 
            this.labelUti.AutoSize = true;
            this.labelUti.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelUti.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUti.ForeColor = System.Drawing.Color.Gold;
            this.labelUti.Location = new System.Drawing.Point(3, 0);
            this.labelUti.Name = "labelUti";
            this.labelUti.Size = new System.Drawing.Size(388, 22);
            this.labelUti.TabIndex = 0;
            this.labelUti.Text = "Utilisateur";
            this.labelUti.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.labelUti.Click += new System.EventHandler(this.labelUti_Click);
            // 
            // panelTitre
            // 
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(3, 3);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(1182, 19);
            this.panelTitre.TabIndex = 2;
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(1157, 0);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 22);
            this.labelFermeture.TabIndex = 2;
            this.labelFermeture.Text = "X";
            this.labelFermeture.Click += new System.EventHandler(this.labelFermeture_Click);
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(32, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(105, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "Belle Table";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panelUtilisateur
            // 
            this.panelUtilisateur.Controls.Add(this.dataGridViewInterUti);
            this.panelUtilisateur.Controls.Add(this.buttonSuppUti);
            this.panelUtilisateur.Controls.Add(this.buttonModUti);
            this.panelUtilisateur.Controls.Add(this.buttonAddUti);
            this.panelUtilisateur.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelUtilisateur.Location = new System.Drawing.Point(1, 70);
            this.panelUtilisateur.Name = "panelUtilisateur";
            this.panelUtilisateur.Size = new System.Drawing.Size(1186, 579);
            this.panelUtilisateur.TabIndex = 2;
            this.panelUtilisateur.Visible = false;
            // 
            // dataGridViewInterUti
            // 
            this.dataGridViewInterUti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewInterUti.Location = new System.Drawing.Point(39, 95);
            this.dataGridViewInterUti.Name = "dataGridViewInterUti";
            this.dataGridViewInterUti.RowTemplate.Height = 28;
            this.dataGridViewInterUti.Size = new System.Drawing.Size(1113, 446);
            this.dataGridViewInterUti.TabIndex = 3;
            // 
            // buttonSuppUti
            // 
            this.buttonSuppUti.BackColor = System.Drawing.Color.Gold;
            this.buttonSuppUti.Location = new System.Drawing.Point(567, 34);
            this.buttonSuppUti.Name = "buttonSuppUti";
            this.buttonSuppUti.Size = new System.Drawing.Size(230, 34);
            this.buttonSuppUti.TabIndex = 2;
            this.buttonSuppUti.Text = "Supprimer utilisateur";
            this.buttonSuppUti.UseVisualStyleBackColor = false;
            // 
            // buttonModUti
            // 
            this.buttonModUti.BackColor = System.Drawing.Color.Gold;
            this.buttonModUti.Location = new System.Drawing.Point(297, 34);
            this.buttonModUti.Name = "buttonModUti";
            this.buttonModUti.Size = new System.Drawing.Size(230, 34);
            this.buttonModUti.TabIndex = 1;
            this.buttonModUti.Text = "Modifier utilisateur";
            this.buttonModUti.UseVisualStyleBackColor = false;
            this.buttonModUti.Click += new System.EventHandler(this.buttonModUti_Click);
            // 
            // buttonAddUti
            // 
            this.buttonAddUti.BackColor = System.Drawing.Color.Gold;
            this.buttonAddUti.Location = new System.Drawing.Point(21, 34);
            this.buttonAddUti.Name = "buttonAddUti";
            this.buttonAddUti.Size = new System.Drawing.Size(230, 34);
            this.buttonAddUti.TabIndex = 0;
            this.buttonAddUti.Text = "Ajouter utilisateur";
            this.buttonAddUti.UseVisualStyleBackColor = false;
            this.buttonAddUti.Click += new System.EventHandler(this.buttonAddUti_Click);
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 70);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 580);
            this.panelBordeLeft.TabIndex = 4;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(1, 649);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(1187, 1);
            this.panelBorderBottom.TabIndex = 5;
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(1187, 70);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 579);
            this.panelBorderRight.TabIndex = 6;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = global::Maquette_Belle_Table.Properties.Resources.Logo_BT2;
            this.pictureBox2.Location = new System.Drawing.Point(0, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1188, 580);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table.Properties.Resources.table;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(26, 25);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // panelHistoriqueC
            // 
            this.panelHistoriqueC.Controls.Add(this.dataGridView1);
            this.panelHistoriqueC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHistoriqueC.Location = new System.Drawing.Point(1, 70);
            this.panelHistoriqueC.Name = "panelHistoriqueC";
            this.panelHistoriqueC.Size = new System.Drawing.Size(1186, 579);
            this.panelHistoriqueC.TabIndex = 4;
            this.panelHistoriqueC.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 34);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1163, 495);
            this.dataGridView1.TabIndex = 0;
            // 
            // panelChangerMDP
            // 
            this.panelChangerMDP.Controls.Add(this.buttonValCM);
            this.panelChangerMDP.Controls.Add(this.textBoxNoMDP);
            this.panelChangerMDP.Controls.Add(this.textBoxLog);
            this.panelChangerMDP.Controls.Add(this.labelNoMDP);
            this.panelChangerMDP.Controls.Add(this.labelLogC);
            this.panelChangerMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChangerMDP.Location = new System.Drawing.Point(1, 70);
            this.panelChangerMDP.Name = "panelChangerMDP";
            this.panelChangerMDP.Size = new System.Drawing.Size(1186, 579);
            this.panelChangerMDP.TabIndex = 7;
            this.panelChangerMDP.Visible = false;
            // 
            // labelLogC
            // 
            this.labelLogC.AutoSize = true;
            this.labelLogC.Location = new System.Drawing.Point(150, 77);
            this.labelLogC.Name = "labelLogC";
            this.labelLogC.Size = new System.Drawing.Size(59, 21);
            this.labelLogC.TabIndex = 0;
            this.labelLogC.Text = "Login :";
            // 
            // labelNoMDP
            // 
            this.labelNoMDP.AutoSize = true;
            this.labelNoMDP.Location = new System.Drawing.Point(73, 134);
            this.labelNoMDP.Name = "labelNoMDP";
            this.labelNoMDP.Size = new System.Drawing.Size(200, 21);
            this.labelNoMDP.TabIndex = 1;
            this.labelNoMDP.Text = "Nouveau mot de passe :";
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(279, 74);
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(216, 27);
            this.textBoxLog.TabIndex = 2;
            // 
            // textBoxNoMDP
            // 
            this.textBoxNoMDP.Location = new System.Drawing.Point(279, 131);
            this.textBoxNoMDP.Name = "textBoxNoMDP";
            this.textBoxNoMDP.Size = new System.Drawing.Size(248, 27);
            this.textBoxNoMDP.TabIndex = 3;
            // 
            // buttonValCM
            // 
            this.buttonValCM.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonValCM.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValCM.ForeColor = System.Drawing.Color.Gold;
            this.buttonValCM.Location = new System.Drawing.Point(437, 199);
            this.buttonValCM.Name = "buttonValCM";
            this.buttonValCM.Size = new System.Drawing.Size(90, 32);
            this.buttonValCM.TabIndex = 16;
            this.buttonValCM.Text = "Valider";
            this.buttonValCM.UseVisualStyleBackColor = false;
            // 
            // InterfaceAd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1188, 650);
            this.Controls.Add(this.panelChangerMDP);
            this.Controls.Add(this.panelHistoriqueC);
            this.Controls.Add(this.panelUtilisateur);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panelMenu);
            this.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "InterfaceAd";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.panelMenu.ResumeLayout(false);
            this.tableLayoutPanelPt3.ResumeLayout(false);
            this.tableLayoutPanel3Trait.ResumeLayout(false);
            this.tableLayoutPanelNomMe.ResumeLayout(false);
            this.tableLayoutPanelNomMe.PerformLayout();
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            this.panelUtilisateur.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInterUti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.panelHistoriqueC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panelChangerMDP.ResumeLayout(false);
            this.panelChangerMDP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPt3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3Trait;
        private System.Windows.Forms.Panel panelCMDP;
        private System.Windows.Forms.Panel panelHC;
        private System.Windows.Forms.Panel panelUti;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelNomMe;
        private System.Windows.Forms.Label labelCMDP;
        private System.Windows.Forms.Label labelHC;
        private System.Windows.Forms.Label labelUti;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panelUtilisateur;
        private System.Windows.Forms.DataGridView dataGridViewInterUti;
        private System.Windows.Forms.Button buttonSuppUti;
        private System.Windows.Forms.Button buttonModUti;
        private System.Windows.Forms.Button buttonAddUti;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelHistoriqueC;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panelChangerMDP;
        private System.Windows.Forms.TextBox textBoxNoMDP;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Label labelNoMDP;
        private System.Windows.Forms.Label labelLogC;
        private System.Windows.Forms.Button buttonValCM;
    }
}