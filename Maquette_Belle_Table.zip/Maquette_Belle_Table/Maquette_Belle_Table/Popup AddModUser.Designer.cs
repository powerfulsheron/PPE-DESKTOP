﻿namespace Maquette_Belle_Table
{
    partial class Popup_AddModUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.panelTypeP = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.labelTypeP = new System.Windows.Forms.Label();
            this.panelCom = new System.Windows.Forms.Panel();
            this.buttonVal = new System.Windows.Forms.Button();
            this.buttonAnul = new System.Windows.Forms.Button();
            this.textBoxEm = new System.Windows.Forms.TextBox();
            this.textBoxTel = new System.Windows.Forms.TextBox();
            this.textBoxPre = new System.Windows.Forms.TextBox();
            this.textBoxNom = new System.Windows.Forms.TextBox();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.groupBoxAP = new System.Windows.Forms.GroupBox();
            this.textBoxVille = new System.Windows.Forms.TextBox();
            this.textBoxCp = new System.Windows.Forms.TextBox();
            this.textBoxRue = new System.Windows.Forms.TextBox();
            this.labelRue = new System.Windows.Forms.Label();
            this.labelCP = new System.Windows.Forms.Label();
            this.labelVille = new System.Windows.Forms.Label();
            this.labelNom = new System.Windows.Forms.Label();
            this.labelTel = new System.Windows.Forms.Label();
            this.labelEm = new System.Windows.Forms.Label();
            this.labelPre = new System.Windows.Forms.Label();
            this.labelLogCom = new System.Windows.Forms.Label();
            this.panelAdmin = new System.Windows.Forms.Panel();
            this.buttonValAd = new System.Windows.Forms.Button();
            this.buttonAnulAd = new System.Windows.Forms.Button();
            this.textBoxLogAd = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panelGest = new System.Windows.Forms.Panel();
            this.buttonValGest = new System.Windows.Forms.Button();
            this.buttonAnuGest = new System.Windows.Forms.Button();
            this.textBoxLogGest = new System.Windows.Forms.TextBox();
            this.labelLogGest = new System.Windows.Forms.Label();
            this.panelMenu.SuspendLayout();
            this.panelTitre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.panelTypeP.SuspendLayout();
            this.panelCom.SuspendLayout();
            this.groupBoxAP.SuspendLayout();
            this.panelAdmin.SuspendLayout();
            this.panelGest.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(0, 583);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(600, 1);
            this.panelBorderBottom.TabIndex = 6;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 0);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 583);
            this.panelBordeLeft.TabIndex = 7;
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(599, 0);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 583);
            this.panelBorderRight.TabIndex = 8;
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelMenu.Controls.Add(this.panelTitre);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(1, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(598, 30);
            this.panelMenu.TabIndex = 9;
            // 
            // panelTitre
            // 
            this.panelTitre.Controls.Add(this.label1);
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(0, 0);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(598, 30);
            this.panelTitre.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MidnightBlue;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(554, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(1157, 0);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 22);
            this.labelFermeture.TabIndex = 2;
            this.labelFermeture.Text = "X";
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(32, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(65, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "GEPEV";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table.Properties.Resources.table;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(26, 25);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // panelTypeP
            // 
            this.panelTypeP.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelTypeP.Controls.Add(this.comboBox1);
            this.panelTypeP.Controls.Add(this.labelTypeP);
            this.panelTypeP.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTypeP.Location = new System.Drawing.Point(1, 30);
            this.panelTypeP.Name = "panelTypeP";
            this.panelTypeP.Size = new System.Drawing.Size(598, 62);
            this.panelTypeP.TabIndex = 10;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Commercial",
            "Gestionnaire",
            "Administrateur"});
            this.comboBox1.Location = new System.Drawing.Point(140, 15);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 29);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // labelTypeP
            // 
            this.labelTypeP.AutoSize = true;
            this.labelTypeP.BackColor = System.Drawing.Color.Transparent;
            this.labelTypeP.Location = new System.Drawing.Point(12, 23);
            this.labelTypeP.Name = "labelTypeP";
            this.labelTypeP.Size = new System.Drawing.Size(121, 21);
            this.labelTypeP.TabIndex = 0;
            this.labelTypeP.Text = "Type de profil :";
            // 
            // panelCom
            // 
            this.panelCom.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelCom.Controls.Add(this.buttonVal);
            this.panelCom.Controls.Add(this.buttonAnul);
            this.panelCom.Controls.Add(this.textBoxEm);
            this.panelCom.Controls.Add(this.textBoxTel);
            this.panelCom.Controls.Add(this.textBoxPre);
            this.panelCom.Controls.Add(this.textBoxNom);
            this.panelCom.Controls.Add(this.textBoxLog);
            this.panelCom.Controls.Add(this.groupBoxAP);
            this.panelCom.Controls.Add(this.labelNom);
            this.panelCom.Controls.Add(this.labelTel);
            this.panelCom.Controls.Add(this.labelEm);
            this.panelCom.Controls.Add(this.labelPre);
            this.panelCom.Controls.Add(this.labelLogCom);
            this.panelCom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCom.Location = new System.Drawing.Point(1, 92);
            this.panelCom.Name = "panelCom";
            this.panelCom.Size = new System.Drawing.Size(598, 491);
            this.panelCom.TabIndex = 11;
            // 
            // buttonVal
            // 
            this.buttonVal.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonVal.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonVal.ForeColor = System.Drawing.Color.Gold;
            this.buttonVal.Location = new System.Drawing.Point(442, 435);
            this.buttonVal.Name = "buttonVal";
            this.buttonVal.Size = new System.Drawing.Size(90, 32);
            this.buttonVal.TabIndex = 15;
            this.buttonVal.Text = "Valider";
            this.buttonVal.UseVisualStyleBackColor = false;
            // 
            // buttonAnul
            // 
            this.buttonAnul.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnul.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnul.ForeColor = System.Drawing.Color.Gold;
            this.buttonAnul.Location = new System.Drawing.Point(70, 435);
            this.buttonAnul.Name = "buttonAnul";
            this.buttonAnul.Size = new System.Drawing.Size(90, 32);
            this.buttonAnul.TabIndex = 14;
            this.buttonAnul.Text = "Annuler";
            this.buttonAnul.UseVisualStyleBackColor = false;
            // 
            // textBoxEm
            // 
            this.textBoxEm.Location = new System.Drawing.Point(70, 165);
            this.textBoxEm.Name = "textBoxEm";
            this.textBoxEm.Size = new System.Drawing.Size(298, 27);
            this.textBoxEm.TabIndex = 11;
            // 
            // textBoxTel
            // 
            this.textBoxTel.Location = new System.Drawing.Point(70, 118);
            this.textBoxTel.Name = "textBoxTel";
            this.textBoxTel.Size = new System.Drawing.Size(158, 27);
            this.textBoxTel.TabIndex = 13;
            // 
            // textBoxPre
            // 
            this.textBoxPre.Location = new System.Drawing.Point(365, 71);
            this.textBoxPre.Name = "textBoxPre";
            this.textBoxPre.Size = new System.Drawing.Size(211, 27);
            this.textBoxPre.TabIndex = 12;
            // 
            // textBoxNom
            // 
            this.textBoxNom.Location = new System.Drawing.Point(70, 71);
            this.textBoxNom.Name = "textBoxNom";
            this.textBoxNom.Size = new System.Drawing.Size(191, 27);
            this.textBoxNom.TabIndex = 11;
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(70, 26);
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(158, 27);
            this.textBoxLog.TabIndex = 10;
            // 
            // groupBoxAP
            // 
            this.groupBoxAP.Controls.Add(this.textBoxVille);
            this.groupBoxAP.Controls.Add(this.textBoxCp);
            this.groupBoxAP.Controls.Add(this.textBoxRue);
            this.groupBoxAP.Controls.Add(this.labelRue);
            this.groupBoxAP.Controls.Add(this.labelCP);
            this.groupBoxAP.Controls.Add(this.labelVille);
            this.groupBoxAP.Location = new System.Drawing.Point(16, 230);
            this.groupBoxAP.Name = "groupBoxAP";
            this.groupBoxAP.Size = new System.Drawing.Size(567, 180);
            this.groupBoxAP.TabIndex = 9;
            this.groupBoxAP.TabStop = false;
            this.groupBoxAP.Text = "Adresse personnelle";
            // 
            // textBoxVille
            // 
            this.textBoxVille.Location = new System.Drawing.Point(60, 135);
            this.textBoxVille.Name = "textBoxVille";
            this.textBoxVille.Size = new System.Drawing.Size(279, 27);
            this.textBoxVille.TabIndex = 13;
            // 
            // textBoxCp
            // 
            this.textBoxCp.Location = new System.Drawing.Point(124, 94);
            this.textBoxCp.Name = "textBoxCp";
            this.textBoxCp.Size = new System.Drawing.Size(138, 27);
            this.textBoxCp.TabIndex = 12;
            // 
            // textBoxRue
            // 
            this.textBoxRue.Location = new System.Drawing.Point(61, 43);
            this.textBoxRue.Name = "textBoxRue";
            this.textBoxRue.Size = new System.Drawing.Size(494, 27);
            this.textBoxRue.TabIndex = 11;
            // 
            // labelRue
            // 
            this.labelRue.AutoSize = true;
            this.labelRue.Location = new System.Drawing.Point(7, 43);
            this.labelRue.Name = "labelRue";
            this.labelRue.Size = new System.Drawing.Size(48, 21);
            this.labelRue.TabIndex = 5;
            this.labelRue.Text = "Rue :";
            // 
            // labelCP
            // 
            this.labelCP.AutoSize = true;
            this.labelCP.Location = new System.Drawing.Point(7, 97);
            this.labelCP.Name = "labelCP";
            this.labelCP.Size = new System.Drawing.Size(114, 21);
            this.labelCP.TabIndex = 4;
            this.labelCP.Text = "Code postal :";
            // 
            // labelVille
            // 
            this.labelVille.AutoSize = true;
            this.labelVille.Location = new System.Drawing.Point(7, 138);
            this.labelVille.Name = "labelVille";
            this.labelVille.Size = new System.Drawing.Size(48, 21);
            this.labelVille.TabIndex = 3;
            this.labelVille.Text = "Ville :";
            // 
            // labelNom
            // 
            this.labelNom.AutoSize = true;
            this.labelNom.Location = new System.Drawing.Point(11, 74);
            this.labelNom.Name = "labelNom";
            this.labelNom.Size = new System.Drawing.Size(55, 21);
            this.labelNom.TabIndex = 8;
            this.labelNom.Text = "Nom :";
            // 
            // labelTel
            // 
            this.labelTel.AutoSize = true;
            this.labelTel.Location = new System.Drawing.Point(11, 124);
            this.labelTel.Name = "labelTel";
            this.labelTel.Size = new System.Drawing.Size(39, 21);
            this.labelTel.TabIndex = 7;
            this.labelTel.Text = "Tél :";
            // 
            // labelEm
            // 
            this.labelEm.AutoSize = true;
            this.labelEm.Location = new System.Drawing.Point(11, 168);
            this.labelEm.Name = "labelEm";
            this.labelEm.Size = new System.Drawing.Size(59, 21);
            this.labelEm.TabIndex = 6;
            this.labelEm.Text = "Email :";
            // 
            // labelPre
            // 
            this.labelPre.AutoSize = true;
            this.labelPre.Location = new System.Drawing.Point(278, 74);
            this.labelPre.Name = "labelPre";
            this.labelPre.Size = new System.Drawing.Size(77, 21);
            this.labelPre.TabIndex = 2;
            this.labelPre.Text = "Prénom :";
            // 
            // labelLogCom
            // 
            this.labelLogCom.AutoSize = true;
            this.labelLogCom.Location = new System.Drawing.Point(12, 32);
            this.labelLogCom.Name = "labelLogCom";
            this.labelLogCom.Size = new System.Drawing.Size(59, 21);
            this.labelLogCom.TabIndex = 0;
            this.labelLogCom.Text = "Login :";
            // 
            // panelAdmin
            // 
            this.panelAdmin.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelAdmin.Controls.Add(this.buttonValAd);
            this.panelAdmin.Controls.Add(this.buttonAnulAd);
            this.panelAdmin.Controls.Add(this.textBoxLogAd);
            this.panelAdmin.Controls.Add(this.label9);
            this.panelAdmin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAdmin.Location = new System.Drawing.Point(1, 92);
            this.panelAdmin.Name = "panelAdmin";
            this.panelAdmin.Size = new System.Drawing.Size(598, 491);
            this.panelAdmin.TabIndex = 12;
            this.panelAdmin.Visible = false;
            // 
            // buttonValAd
            // 
            this.buttonValAd.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonValAd.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValAd.ForeColor = System.Drawing.Color.Gold;
            this.buttonValAd.Location = new System.Drawing.Point(423, 113);
            this.buttonValAd.Name = "buttonValAd";
            this.buttonValAd.Size = new System.Drawing.Size(90, 32);
            this.buttonValAd.TabIndex = 15;
            this.buttonValAd.Text = "Valider";
            this.buttonValAd.UseVisualStyleBackColor = false;
            // 
            // buttonAnulAd
            // 
            this.buttonAnulAd.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnulAd.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnulAd.ForeColor = System.Drawing.Color.Gold;
            this.buttonAnulAd.Location = new System.Drawing.Point(56, 113);
            this.buttonAnulAd.Name = "buttonAnulAd";
            this.buttonAnulAd.Size = new System.Drawing.Size(90, 32);
            this.buttonAnulAd.TabIndex = 14;
            this.buttonAnulAd.Text = "Annuler";
            this.buttonAnulAd.UseVisualStyleBackColor = false;
            // 
            // textBoxLogAd
            // 
            this.textBoxLogAd.Location = new System.Drawing.Point(70, 26);
            this.textBoxLogAd.Name = "textBoxLogAd";
            this.textBoxLogAd.Size = new System.Drawing.Size(158, 27);
            this.textBoxLogAd.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 21);
            this.label9.TabIndex = 0;
            this.label9.Text = "Login :";
            // 
            // panelGest
            // 
            this.panelGest.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.panelGest.Controls.Add(this.buttonValGest);
            this.panelGest.Controls.Add(this.buttonAnuGest);
            this.panelGest.Controls.Add(this.textBoxLogGest);
            this.panelGest.Controls.Add(this.labelLogGest);
            this.panelGest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGest.Location = new System.Drawing.Point(1, 92);
            this.panelGest.Name = "panelGest";
            this.panelGest.Size = new System.Drawing.Size(598, 491);
            this.panelGest.TabIndex = 13;
            this.panelGest.Visible = false;
            // 
            // buttonValGest
            // 
            this.buttonValGest.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonValGest.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValGest.ForeColor = System.Drawing.Color.Gold;
            this.buttonValGest.Location = new System.Drawing.Point(423, 113);
            this.buttonValGest.Name = "buttonValGest";
            this.buttonValGest.Size = new System.Drawing.Size(90, 32);
            this.buttonValGest.TabIndex = 15;
            this.buttonValGest.Text = "Valider";
            this.buttonValGest.UseVisualStyleBackColor = false;
            // 
            // buttonAnuGest
            // 
            this.buttonAnuGest.BackColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnuGest.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnuGest.ForeColor = System.Drawing.Color.Gold;
            this.buttonAnuGest.Location = new System.Drawing.Point(56, 113);
            this.buttonAnuGest.Name = "buttonAnuGest";
            this.buttonAnuGest.Size = new System.Drawing.Size(90, 32);
            this.buttonAnuGest.TabIndex = 14;
            this.buttonAnuGest.Text = "Annuler";
            this.buttonAnuGest.UseVisualStyleBackColor = false;
            // 
            // textBoxLogGest
            // 
            this.textBoxLogGest.Location = new System.Drawing.Point(70, 26);
            this.textBoxLogGest.Name = "textBoxLogGest";
            this.textBoxLogGest.Size = new System.Drawing.Size(158, 27);
            this.textBoxLogGest.TabIndex = 10;
            // 
            // labelLogGest
            // 
            this.labelLogGest.AutoSize = true;
            this.labelLogGest.BackColor = System.Drawing.Color.Transparent;
            this.labelLogGest.Location = new System.Drawing.Point(12, 32);
            this.labelLogGest.Name = "labelLogGest";
            this.labelLogGest.Size = new System.Drawing.Size(59, 21);
            this.labelLogGest.TabIndex = 0;
            this.labelLogGest.Text = "Login :";
            // 
            // Popup_AddModUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::Maquette_Belle_Table.Properties.Resources.fond2;
            this.ClientSize = new System.Drawing.Size(600, 584);
            this.Controls.Add(this.panelGest);
            this.Controls.Add(this.panelAdmin);
            this.Controls.Add(this.panelCom);
            this.Controls.Add(this.panelTypeP);
            this.Controls.Add(this.panelMenu);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.panelBorderBottom);
            this.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Popup_AddModUser";
            this.Text = "Popup_AddModUser";
            this.panelMenu.ResumeLayout(false);
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.panelTypeP.ResumeLayout(false);
            this.panelTypeP.PerformLayout();
            this.panelCom.ResumeLayout(false);
            this.panelCom.PerformLayout();
            this.groupBoxAP.ResumeLayout(false);
            this.groupBoxAP.PerformLayout();
            this.panelAdmin.ResumeLayout(false);
            this.panelAdmin.PerformLayout();
            this.panelGest.ResumeLayout(false);
            this.panelGest.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelTypeP;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label labelTypeP;
        private System.Windows.Forms.Panel panelCom;
        private System.Windows.Forms.Button buttonVal;
        private System.Windows.Forms.Button buttonAnul;
        private System.Windows.Forms.TextBox textBoxEm;
        private System.Windows.Forms.TextBox textBoxTel;
        private System.Windows.Forms.TextBox textBoxPre;
        private System.Windows.Forms.TextBox textBoxNom;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.GroupBox groupBoxAP;
        private System.Windows.Forms.TextBox textBoxVille;
        private System.Windows.Forms.TextBox textBoxCp;
        private System.Windows.Forms.TextBox textBoxRue;
        private System.Windows.Forms.Label labelRue;
        private System.Windows.Forms.Label labelCP;
        private System.Windows.Forms.Label labelVille;
        private System.Windows.Forms.Label labelNom;
        private System.Windows.Forms.Label labelTel;
        private System.Windows.Forms.Label labelEm;
        private System.Windows.Forms.Label labelPre;
        private System.Windows.Forms.Label labelLogCom;
        private System.Windows.Forms.Panel panelAdmin;
        private System.Windows.Forms.Button buttonValAd;
        private System.Windows.Forms.Button buttonAnulAd;
        private System.Windows.Forms.TextBox textBoxLogAd;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panelGest;
        private System.Windows.Forms.Button buttonValGest;
        private System.Windows.Forms.Button buttonAnuGest;
        private System.Windows.Forms.TextBox textBoxLogGest;
        private System.Windows.Forms.Label labelLogGest;
    }
}