﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maquette_Belle_Table
{
    public partial class InterfaceGes : Form
    {
        public InterfaceGes()
        {
            InitializeComponent();
        }

        private void labelPla_Click(object sender, EventArgs e)
        {
            panelPlan.Show();
            panelPlanC.Hide();
            panelPF.Hide();
            panelMails.Hide();
            panelCMDP.Hide();
            labelPla.ForeColor = Color.Gold;
            labelPlaC.ForeColor = Color.White;
            labelPF.ForeColor = Color.White;
            labelMails.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.White;
            panelPlanning.Visible = true;
            panelPlanningC.Visible = false;
            panelPortefeuille.Visible = false;
            panelMails.Visible = false;
            panelChangerMDP.Visible = false;
        }

        private void labelPlaC_Click(object sender, EventArgs e)
        {
            panelPlan.Hide();
            panelPlanC.Show();
            panelPF.Hide();
            panelMails.Hide();
            panelCMDP.Hide();
            labelPla.ForeColor = Color.White;
            labelPlaC.ForeColor = Color.Gold;
            labelPF.ForeColor = Color.White;
            labelMails.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.White;
            panelPlanning.Visible = false;
            panelPlanningC.Visible = true;
            panelPortefeuille.Visible = false;
            panelMails.Visible = false;
            panelChangerMDP.Visible = false;
        }

        private void labelPF_Click(object sender, EventArgs e)
        {
            panelPlan.Hide();
            panelPlanC.Hide();
            panelPF.Show();
            panelMails.Hide();
            panelCMDP.Hide();
            labelPla.ForeColor = Color.White;
            labelPlaC.ForeColor = Color.White;
            labelPF.ForeColor = Color.Gold;
            labelMails.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.White;
            panelPlanning.Visible = false;
            panelPlanningC.Visible = false;
            panelPortefeuille.Visible = true;
            panelMails.Visible = false;
            panelChangerMDP.Visible = false;
        }

        private void labelMails_Click(object sender, EventArgs e)
        {
            panelPlan.Hide();
            panelPlanC.Hide();
            panelPF.Hide();
            panelMails.Show();
            panelCMDP.Hide();
            labelPla.ForeColor = Color.White;
            labelPlaC.ForeColor = Color.White;
            labelPF.ForeColor = Color.White;
            labelMails.ForeColor = Color.Gold;
            labelCMDP.ForeColor = Color.White;
            panelPlanning.Visible = false;
            panelPlanningC.Visible = false;
            panelPortefeuille.Visible = false;
            panelMail.Visible = true;
            panelChangerMDP.Visible = false;
        }

        private void labelCMDP_Click(object sender, EventArgs e)
        {
            panelPlan.Hide();
            panelPlanC.Hide();
            panelPF.Hide();
            panelMails.Hide();
            panelCMDP.Show();
            labelPla.ForeColor = Color.White;
            labelPlaC.ForeColor = Color.White;
            labelPF.ForeColor = Color.White;
            labelMails.ForeColor = Color.White;
            labelCMDP.ForeColor = Color.Gold;
            panelPlanning.Visible = false;
            panelPlanningC.Visible = false;
            panelPortefeuille.Visible = false;
            panelMails.Visible = false;
            panelChangerMDP.Visible = true;
        }

        private void panelPlanning_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonNRDV_Click(object sender, EventArgs e)
        {
            new PopNouveauRDV().Show();
        }

        private void groupBoxPJS_Enter(object sender, EventArgs e)
        {

        }

        private void buttonNPC_Click(object sender, EventArgs e)
        {
            new Popup_NewC().Show();
        }
        private void labelClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
