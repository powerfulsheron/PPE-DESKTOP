﻿namespace Maquette_Belle_Table
{
    partial class Popup_Mail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.textBoxObjet = new System.Windows.Forms.TextBox();
            this.labelCci = new System.Windows.Forms.Label();
            this.textBoxA = new System.Windows.Forms.TextBox();
            this.labelCc = new System.Windows.Forms.Label();
            this.textBoxCc = new System.Windows.Forms.TextBox();
            this.labelA = new System.Windows.Forms.Label();
            this.textBoxCci = new System.Windows.Forms.TextBox();
            this.labelObjet = new System.Windows.Forms.Label();
            this.textBoxMail = new System.Windows.Forms.TextBox();
            this.buttonEnvoyer = new System.Windows.Forms.Button();
            this.buttonAnnuler = new System.Windows.Forms.Button();
            this.buttonRetour = new System.Windows.Forms.Button();
            this.panelMenu.SuspendLayout();
            this.panelTitre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelMenu.Controls.Add(this.panelTitre);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(667, 31);
            this.panelMenu.TabIndex = 11;
            // 
            // panelTitre
            // 
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.label1);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(0, 0);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(667, 31);
            this.panelTitre.TabIndex = 2;
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.MidnightBlue;
            this.labelFermeture.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(1286, 0);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 22);
            this.labelFermeture.TabIndex = 2;
            this.labelFermeture.Text = "X";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.MidnightBlue;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(633, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 22);
            this.label1.TabIndex = 3;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(36, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(65, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "GEPEV";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table_Final.Properties.Resources.table;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(29, 26);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(666, 31);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 582);
            this.panelBorderRight.TabIndex = 12;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 31);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 582);
            this.panelBordeLeft.TabIndex = 12;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(1, 612);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(665, 1);
            this.panelBorderBottom.TabIndex = 13;
            // 
            // textBoxObjet
            // 
            this.textBoxObjet.Location = new System.Drawing.Point(75, 211);
            this.textBoxObjet.Name = "textBoxObjet";
            this.textBoxObjet.Size = new System.Drawing.Size(542, 27);
            this.textBoxObjet.TabIndex = 42;
            // 
            // labelCci
            // 
            this.labelCci.AutoSize = true;
            this.labelCci.BackColor = System.Drawing.Color.Transparent;
            this.labelCci.Location = new System.Drawing.Point(10, 161);
            this.labelCci.Name = "labelCci";
            this.labelCci.Size = new System.Drawing.Size(44, 21);
            this.labelCci.TabIndex = 41;
            this.labelCci.Text = "Cci :";
            // 
            // textBoxA
            // 
            this.textBoxA.Location = new System.Drawing.Point(75, 61);
            this.textBoxA.Name = "textBoxA";
            this.textBoxA.Size = new System.Drawing.Size(542, 27);
            this.textBoxA.TabIndex = 40;
            // 
            // labelCc
            // 
            this.labelCc.AutoSize = true;
            this.labelCc.BackColor = System.Drawing.Color.Transparent;
            this.labelCc.Location = new System.Drawing.Point(8, 112);
            this.labelCc.Name = "labelCc";
            this.labelCc.Size = new System.Drawing.Size(41, 21);
            this.labelCc.TabIndex = 39;
            this.labelCc.Text = "Cc :";
            // 
            // textBoxCc
            // 
            this.textBoxCc.Location = new System.Drawing.Point(75, 109);
            this.textBoxCc.Name = "textBoxCc";
            this.textBoxCc.Size = new System.Drawing.Size(542, 27);
            this.textBoxCc.TabIndex = 38;
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.BackColor = System.Drawing.Color.Transparent;
            this.labelA.Location = new System.Drawing.Point(8, 64);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(31, 21);
            this.labelA.TabIndex = 37;
            this.labelA.Text = "A :";
            // 
            // textBoxCci
            // 
            this.textBoxCci.Location = new System.Drawing.Point(75, 158);
            this.textBoxCci.Name = "textBoxCci";
            this.textBoxCci.Size = new System.Drawing.Size(542, 27);
            this.textBoxCci.TabIndex = 34;
            // 
            // labelObjet
            // 
            this.labelObjet.AutoSize = true;
            this.labelObjet.BackColor = System.Drawing.Color.Transparent;
            this.labelObjet.Location = new System.Drawing.Point(8, 214);
            this.labelObjet.Name = "labelObjet";
            this.labelObjet.Size = new System.Drawing.Size(63, 21);
            this.labelObjet.TabIndex = 33;
            this.labelObjet.Text = "Objet :";
            // 
            // textBoxMail
            // 
            this.textBoxMail.Location = new System.Drawing.Point(14, 261);
            this.textBoxMail.Multiline = true;
            this.textBoxMail.Name = "textBoxMail";
            this.textBoxMail.Size = new System.Drawing.Size(641, 300);
            this.textBoxMail.TabIndex = 32;
            // 
            // buttonEnvoyer
            // 
            this.buttonEnvoyer.BackColor = System.Drawing.Color.Gold;
            this.buttonEnvoyer.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEnvoyer.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonEnvoyer.Location = new System.Drawing.Point(497, 569);
            this.buttonEnvoyer.Name = "buttonEnvoyer";
            this.buttonEnvoyer.Size = new System.Drawing.Size(90, 32);
            this.buttonEnvoyer.TabIndex = 44;
            this.buttonEnvoyer.Text = "Envoyer";
            this.buttonEnvoyer.UseVisualStyleBackColor = false;
            this.buttonEnvoyer.Click += new System.EventHandler(this.buttonEnvoyer_Click);
            // 
            // buttonAnnuler
            // 
            this.buttonAnnuler.BackColor = System.Drawing.Color.Gold;
            this.buttonAnnuler.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnnuler.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonAnnuler.Location = new System.Drawing.Point(117, 569);
            this.buttonAnnuler.Name = "buttonAnnuler";
            this.buttonAnnuler.Size = new System.Drawing.Size(90, 32);
            this.buttonAnnuler.TabIndex = 45;
            this.buttonAnnuler.Text = "Annuler";
            this.buttonAnnuler.UseVisualStyleBackColor = false;
            this.buttonAnnuler.Click += new System.EventHandler(this.buttonAnnuler_Click);
            // 
            // buttonRetour
            // 
            this.buttonRetour.BackColor = System.Drawing.Color.Gold;
            this.buttonRetour.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRetour.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonRetour.Location = new System.Drawing.Point(310, 569);
            this.buttonRetour.Name = "buttonRetour";
            this.buttonRetour.Size = new System.Drawing.Size(90, 32);
            this.buttonRetour.TabIndex = 46;
            this.buttonRetour.Text = "Retour";
            this.buttonRetour.UseVisualStyleBackColor = false;
            this.buttonRetour.Click += new System.EventHandler(this.buttonRetour_Click);
            // 
            // Popup_Mail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 613);
            this.Controls.Add(this.buttonRetour);
            this.Controls.Add(this.buttonAnnuler);
            this.Controls.Add(this.buttonEnvoyer);
            this.Controls.Add(this.textBoxMail);
            this.Controls.Add(this.labelObjet);
            this.Controls.Add(this.textBoxCci);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.textBoxCc);
            this.Controls.Add(this.labelCc);
            this.Controls.Add(this.textBoxA);
            this.Controls.Add(this.labelCci);
            this.Controls.Add(this.textBoxObjet);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.panelMenu);
            this.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Popup_Mail";
            this.Text = "Popup_Mail";
            this.panelMenu.ResumeLayout(false);
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.Panel panelBorderRight;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.TextBox textBoxObjet;
        private System.Windows.Forms.Label labelCci;
        private System.Windows.Forms.TextBox textBoxA;
        private System.Windows.Forms.Label labelCc;
        private System.Windows.Forms.TextBox textBoxCc;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.TextBox textBoxCci;
        private System.Windows.Forms.Label labelObjet;
        private System.Windows.Forms.TextBox textBoxMail;
        private System.Windows.Forms.Button buttonEnvoyer;
        private System.Windows.Forms.Button buttonAnnuler;
        private System.Windows.Forms.Button buttonRetour;
    }
}