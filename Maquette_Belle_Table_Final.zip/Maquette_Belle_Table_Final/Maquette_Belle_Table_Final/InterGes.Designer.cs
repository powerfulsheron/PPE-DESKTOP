﻿namespace Maquette_Belle_Table_Final
{
    partial class InterGes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutEntete = new System.Windows.Forms.TableLayoutPanel();
            this.panelTitre = new System.Windows.Forms.Panel();
            this.labelFermeture = new System.Windows.Forms.Label();
            this.labelBT = new System.Windows.Forms.Label();
            this.pictureBoxBT = new System.Windows.Forms.PictureBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageCom = new System.Windows.Forms.TabPage();
            this.panelPlanning = new System.Windows.Forms.Panel();
            this.dataGridViewCom = new System.Windows.Forms.DataGridView();
            this.buttonVM = new System.Windows.Forms.Button();
            this.buttonSupCom = new System.Windows.Forms.Button();
            this.buttonModCom = new System.Windows.Forms.Button();
            this.buttonAddCom = new System.Windows.Forms.Button();
            this.buttonVRDV = new System.Windows.Forms.Button();
            this.tabPagePF = new System.Windows.Forms.TabPage();
            this.panelPF = new System.Windows.Forms.Panel();
            this.buttonCPF = new System.Windows.Forms.Button();
            this.buttonSupPF = new System.Windows.Forms.Button();
            this.buttonModPF = new System.Windows.Forms.Button();
            this.buttonCrPF = new System.Windows.Forms.Button();
            this.dataGridViewPF = new System.Windows.Forms.DataGridView();
            this.tabPagePFI = new System.Windows.Forms.TabPage();
            this.panelPortefeuille = new System.Windows.Forms.Panel();
            this.dataGridViewPFI = new System.Windows.Forms.DataGridView();
            this.buttonModAssoInter = new System.Windows.Forms.Button();
            this.tabPagePFC = new System.Windows.Forms.TabPage();
            this.panelPFC = new System.Windows.Forms.Panel();
            this.dataGridViewPFC = new System.Windows.Forms.DataGridView();
            this.buttonModAssCom = new System.Windows.Forms.Button();
            this.tabPageCDMDP = new System.Windows.Forms.TabPage();
            this.panelChangerMDP = new System.Windows.Forms.Panel();
            this.buttonValCDMDP = new System.Windows.Forms.Button();
            this.textBoxNoMDP = new System.Windows.Forms.TextBox();
            this.labelNoMDP = new System.Windows.Forms.Label();
            this.labelLogC = new System.Windows.Forms.Label();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.panelBordeLeft = new System.Windows.Forms.Panel();
            this.panelBorderBottom = new System.Windows.Forms.Panel();
            this.panelBorderRight = new System.Windows.Forms.Panel();
            this.tableLayoutEntete.SuspendLayout();
            this.panelTitre.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPageCom.SuspendLayout();
            this.panelPlanning.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCom)).BeginInit();
            this.tabPagePF.SuspendLayout();
            this.panelPF.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPF)).BeginInit();
            this.tabPagePFI.SuspendLayout();
            this.panelPortefeuille.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPFI)).BeginInit();
            this.tabPagePFC.SuspendLayout();
            this.panelPFC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPFC)).BeginInit();
            this.tabPageCDMDP.SuspendLayout();
            this.panelChangerMDP.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutEntete
            // 
            this.tableLayoutEntete.ColumnCount = 1;
            this.tableLayoutEntete.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutEntete.Controls.Add(this.panelTitre, 0, 0);
            this.tableLayoutEntete.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutEntete.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutEntete.Name = "tableLayoutEntete";
            this.tableLayoutEntete.RowCount = 1;
            this.tableLayoutEntete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.78161F));
            this.tableLayoutEntete.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutEntete.Size = new System.Drawing.Size(1000, 37);
            this.tableLayoutEntete.TabIndex = 3;
            // 
            // panelTitre
            // 
            this.panelTitre.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelTitre.Controls.Add(this.labelFermeture);
            this.panelTitre.Controls.Add(this.labelBT);
            this.panelTitre.Controls.Add(this.pictureBoxBT);
            this.panelTitre.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTitre.Location = new System.Drawing.Point(3, 3);
            this.panelTitre.Name = "panelTitre";
            this.panelTitre.Size = new System.Drawing.Size(994, 31);
            this.panelTitre.TabIndex = 2;
            // 
            // labelFermeture
            // 
            this.labelFermeture.AutoSize = true;
            this.labelFermeture.BackColor = System.Drawing.Color.Transparent;
            this.labelFermeture.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFermeture.ForeColor = System.Drawing.Color.Gold;
            this.labelFermeture.Location = new System.Drawing.Point(967, 6);
            this.labelFermeture.Name = "labelFermeture";
            this.labelFermeture.Size = new System.Drawing.Size(22, 21);
            this.labelFermeture.TabIndex = 17;
            this.labelFermeture.Text = "X";
            this.labelFermeture.Click += new System.EventHandler(this.labelFermeture_Click);
            // 
            // labelBT
            // 
            this.labelBT.AutoSize = true;
            this.labelBT.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBT.ForeColor = System.Drawing.Color.Gold;
            this.labelBT.Location = new System.Drawing.Point(36, 0);
            this.labelBT.Name = "labelBT";
            this.labelBT.Size = new System.Drawing.Size(65, 22);
            this.labelBT.TabIndex = 1;
            this.labelBT.Text = "GEPEV";
            this.labelBT.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBoxBT
            // 
            this.pictureBoxBT.Image = global::Maquette_Belle_Table_Final.Properties.Resources.table;
            this.pictureBoxBT.Location = new System.Drawing.Point(0, -3);
            this.pictureBoxBT.Name = "pictureBoxBT";
            this.pictureBoxBT.Size = new System.Drawing.Size(29, 26);
            this.pictureBoxBT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBT.TabIndex = 0;
            this.pictureBoxBT.TabStop = false;
            // 
            // tabControl2
            // 
            this.tabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl2.Controls.Add(this.tabPageCom);
            this.tabControl2.Controls.Add(this.tabPagePF);
            this.tabControl2.Controls.Add(this.tabPagePFI);
            this.tabControl2.Controls.Add(this.tabPagePFC);
            this.tabControl2.Controls.Add(this.tabPageCDMDP);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.tabControl2.Location = new System.Drawing.Point(1, 37);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(998, 499);
            this.tabControl2.TabIndex = 18;
            // 
            // tabPageCom
            // 
            this.tabPageCom.Controls.Add(this.panelPlanning);
            this.tabPageCom.Location = new System.Drawing.Point(4, 33);
            this.tabPageCom.Name = "tabPageCom";
            this.tabPageCom.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCom.Size = new System.Drawing.Size(990, 462);
            this.tabPageCom.TabIndex = 0;
            this.tabPageCom.Text = "Commerciaux";
            this.tabPageCom.UseVisualStyleBackColor = true;
            // 
            // panelPlanning
            // 
            this.panelPlanning.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.panelPlanning.Controls.Add(this.dataGridViewCom);
            this.panelPlanning.Controls.Add(this.buttonVM);
            this.panelPlanning.Controls.Add(this.buttonSupCom);
            this.panelPlanning.Controls.Add(this.buttonModCom);
            this.panelPlanning.Controls.Add(this.buttonAddCom);
            this.panelPlanning.Controls.Add(this.buttonVRDV);
            this.panelPlanning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPlanning.Location = new System.Drawing.Point(3, 3);
            this.panelPlanning.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelPlanning.Name = "panelPlanning";
            this.panelPlanning.Size = new System.Drawing.Size(984, 456);
            this.panelPlanning.TabIndex = 13;
            // 
            // dataGridViewCom
            // 
            this.dataGridViewCom.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCom.Location = new System.Drawing.Point(24, 93);
            this.dataGridViewCom.Name = "dataGridViewCom";
            this.dataGridViewCom.RowTemplate.Height = 28;
            this.dataGridViewCom.Size = new System.Drawing.Size(939, 335);
            this.dataGridViewCom.TabIndex = 8;
            // 
            // buttonVM
            // 
            this.buttonVM.BackColor = System.Drawing.Color.Gold;
            this.buttonVM.Location = new System.Drawing.Point(870, 34);
            this.buttonVM.Name = "buttonVM";
            this.buttonVM.Size = new System.Drawing.Size(110, 34);
            this.buttonVM.TabIndex = 7;
            this.buttonVM.Text = "Voir Mails";
            this.buttonVM.UseVisualStyleBackColor = false;
            this.buttonVM.Click += new System.EventHandler(this.buttonVM_Click);
            // 
            // buttonSupCom
            // 
            this.buttonSupCom.BackColor = System.Drawing.Color.Gold;
            this.buttonSupCom.Location = new System.Drawing.Point(519, 34);
            this.buttonSupCom.Name = "buttonSupCom";
            this.buttonSupCom.Size = new System.Drawing.Size(230, 34);
            this.buttonSupCom.TabIndex = 6;
            this.buttonSupCom.Text = "Supprimer un commercial";
            this.buttonSupCom.UseVisualStyleBackColor = false;
            this.buttonSupCom.Click += new System.EventHandler(this.buttonSupCom_Click);
            // 
            // buttonModCom
            // 
            this.buttonModCom.BackColor = System.Drawing.Color.Gold;
            this.buttonModCom.Location = new System.Drawing.Point(267, 34);
            this.buttonModCom.Name = "buttonModCom";
            this.buttonModCom.Size = new System.Drawing.Size(225, 34);
            this.buttonModCom.TabIndex = 5;
            this.buttonModCom.Text = "Modifier un commercial";
            this.buttonModCom.UseVisualStyleBackColor = false;
            this.buttonModCom.Click += new System.EventHandler(this.buttonModCom_Click);
            // 
            // buttonAddCom
            // 
            this.buttonAddCom.BackColor = System.Drawing.Color.Gold;
            this.buttonAddCom.Location = new System.Drawing.Point(24, 34);
            this.buttonAddCom.Name = "buttonAddCom";
            this.buttonAddCom.Size = new System.Drawing.Size(204, 34);
            this.buttonAddCom.TabIndex = 4;
            this.buttonAddCom.Text = "Ajouter un commercial";
            this.buttonAddCom.UseVisualStyleBackColor = false;
            this.buttonAddCom.Click += new System.EventHandler(this.buttonAddCom_Click);
            // 
            // buttonVRDV
            // 
            this.buttonVRDV.BackColor = System.Drawing.Color.Gold;
            this.buttonVRDV.Location = new System.Drawing.Point(769, 34);
            this.buttonVRDV.Name = "buttonVRDV";
            this.buttonVRDV.Size = new System.Drawing.Size(95, 34);
            this.buttonVRDV.TabIndex = 1;
            this.buttonVRDV.Text = "Voir RDV";
            this.buttonVRDV.UseVisualStyleBackColor = false;
            this.buttonVRDV.Click += new System.EventHandler(this.buttonVRDV_Click);
            // 
            // tabPagePF
            // 
            this.tabPagePF.Controls.Add(this.panelPF);
            this.tabPagePF.Location = new System.Drawing.Point(4, 33);
            this.tabPagePF.Name = "tabPagePF";
            this.tabPagePF.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePF.Size = new System.Drawing.Size(990, 462);
            this.tabPagePF.TabIndex = 1;
            this.tabPagePF.Text = "Portefeuille";
            this.tabPagePF.UseVisualStyleBackColor = true;
            // 
            // panelPF
            // 
            this.panelPF.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.panelPF.Controls.Add(this.buttonCPF);
            this.panelPF.Controls.Add(this.buttonSupPF);
            this.panelPF.Controls.Add(this.buttonModPF);
            this.panelPF.Controls.Add(this.buttonCrPF);
            this.panelPF.Controls.Add(this.dataGridViewPF);
            this.panelPF.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPF.Location = new System.Drawing.Point(3, 3);
            this.panelPF.Name = "panelPF";
            this.panelPF.Size = new System.Drawing.Size(984, 456);
            this.panelPF.TabIndex = 7;
            // 
            // buttonCPF
            // 
            this.buttonCPF.BackColor = System.Drawing.Color.Gold;
            this.buttonCPF.Location = new System.Drawing.Point(791, 37);
            this.buttonCPF.Name = "buttonCPF";
            this.buttonCPF.Size = new System.Drawing.Size(176, 34);
            this.buttonCPF.TabIndex = 4;
            this.buttonCPF.Text = "Créer Portefeuille";
            this.buttonCPF.UseVisualStyleBackColor = false;
            this.buttonCPF.Click += new System.EventHandler(this.buttonCPF_Click);
            // 
            // buttonSupPF
            // 
            this.buttonSupPF.BackColor = System.Drawing.Color.Gold;
            this.buttonSupPF.Location = new System.Drawing.Point(776, 143);
            this.buttonSupPF.Name = "buttonSupPF";
            this.buttonSupPF.Size = new System.Drawing.Size(207, 34);
            this.buttonSupPF.TabIndex = 3;
            this.buttonSupPF.Text = "Supprimer Portefeuille";
            this.buttonSupPF.UseVisualStyleBackColor = false;
            this.buttonSupPF.Click += new System.EventHandler(this.buttonSupPF_Click);
            // 
            // buttonModPF
            // 
            this.buttonModPF.BackColor = System.Drawing.Color.Gold;
            this.buttonModPF.Location = new System.Drawing.Point(782, 92);
            this.buttonModPF.Name = "buttonModPF";
            this.buttonModPF.Size = new System.Drawing.Size(195, 34);
            this.buttonModPF.TabIndex = 2;
            this.buttonModPF.Text = "Modifier Portefeuille";
            this.buttonModPF.UseVisualStyleBackColor = false;
            this.buttonModPF.Click += new System.EventHandler(this.buttonModPF_Click);
            // 
            // buttonCrPF
            // 
            this.buttonCrPF.BackColor = System.Drawing.Color.Gold;
            this.buttonCrPF.Location = new System.Drawing.Point(1281, 513);
            this.buttonCrPF.Name = "buttonCrPF";
            this.buttonCrPF.Size = new System.Drawing.Size(158, 34);
            this.buttonCrPF.TabIndex = 1;
            this.buttonCrPF.Text = "Créer Portefeuille";
            this.buttonCrPF.UseVisualStyleBackColor = false;
            // 
            // dataGridViewPF
            // 
            this.dataGridViewPF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPF.Location = new System.Drawing.Point(19, 37);
            this.dataGridViewPF.Name = "dataGridViewPF";
            this.dataGridViewPF.RowTemplate.Height = 28;
            this.dataGridViewPF.Size = new System.Drawing.Size(735, 387);
            this.dataGridViewPF.TabIndex = 0;
            // 
            // tabPagePFI
            // 
            this.tabPagePFI.Controls.Add(this.panelPortefeuille);
            this.tabPagePFI.Location = new System.Drawing.Point(4, 33);
            this.tabPagePFI.Name = "tabPagePFI";
            this.tabPagePFI.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePFI.Size = new System.Drawing.Size(990, 462);
            this.tabPagePFI.TabIndex = 2;
            this.tabPagePFI.Text = "Portefeuille Interlocuteur";
            this.tabPagePFI.UseVisualStyleBackColor = true;
            // 
            // panelPortefeuille
            // 
            this.panelPortefeuille.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.panelPortefeuille.Controls.Add(this.dataGridViewPFI);
            this.panelPortefeuille.Controls.Add(this.buttonModAssoInter);
            this.panelPortefeuille.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPortefeuille.Location = new System.Drawing.Point(3, 3);
            this.panelPortefeuille.Name = "panelPortefeuille";
            this.panelPortefeuille.Size = new System.Drawing.Size(984, 456);
            this.panelPortefeuille.TabIndex = 4;
            // 
            // dataGridViewPFI
            // 
            this.dataGridViewPFI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPFI.Location = new System.Drawing.Point(35, 75);
            this.dataGridViewPFI.Name = "dataGridViewPFI";
            this.dataGridViewPFI.RowTemplate.Height = 28;
            this.dataGridViewPFI.Size = new System.Drawing.Size(913, 355);
            this.dataGridViewPFI.TabIndex = 4;
            // 
            // buttonModAssoInter
            // 
            this.buttonModAssoInter.BackColor = System.Drawing.Color.Gold;
            this.buttonModAssoInter.Location = new System.Drawing.Point(35, 22);
            this.buttonModAssoInter.Name = "buttonModAssoInter";
            this.buttonModAssoInter.Size = new System.Drawing.Size(245, 34);
            this.buttonModAssoInter.TabIndex = 2;
            this.buttonModAssoInter.Text = "Modifier une association";
            this.buttonModAssoInter.UseVisualStyleBackColor = false;
            this.buttonModAssoInter.Click += new System.EventHandler(this.buttonModAssoInter_Click);
            // 
            // tabPagePFC
            // 
            this.tabPagePFC.Controls.Add(this.panelPFC);
            this.tabPagePFC.Location = new System.Drawing.Point(4, 33);
            this.tabPagePFC.Name = "tabPagePFC";
            this.tabPagePFC.Padding = new System.Windows.Forms.Padding(3);
            this.tabPagePFC.Size = new System.Drawing.Size(990, 462);
            this.tabPagePFC.TabIndex = 3;
            this.tabPagePFC.Text = "Portfeuille Commerciaux";
            this.tabPagePFC.UseVisualStyleBackColor = true;
            // 
            // panelPFC
            // 
            this.panelPFC.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.panelPFC.Controls.Add(this.dataGridViewPFC);
            this.panelPFC.Controls.Add(this.buttonModAssCom);
            this.panelPFC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPFC.Location = new System.Drawing.Point(3, 3);
            this.panelPFC.Name = "panelPFC";
            this.panelPFC.Size = new System.Drawing.Size(984, 456);
            this.panelPFC.TabIndex = 5;
            // 
            // dataGridViewPFC
            // 
            this.dataGridViewPFC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPFC.Location = new System.Drawing.Point(35, 75);
            this.dataGridViewPFC.Name = "dataGridViewPFC";
            this.dataGridViewPFC.RowTemplate.Height = 28;
            this.dataGridViewPFC.Size = new System.Drawing.Size(913, 355);
            this.dataGridViewPFC.TabIndex = 4;
            // 
            // buttonModAssCom
            // 
            this.buttonModAssCom.BackColor = System.Drawing.Color.Gold;
            this.buttonModAssCom.Location = new System.Drawing.Point(35, 22);
            this.buttonModAssCom.Name = "buttonModAssCom";
            this.buttonModAssCom.Size = new System.Drawing.Size(244, 34);
            this.buttonModAssCom.TabIndex = 2;
            this.buttonModAssCom.Text = "Modifier une association";
            this.buttonModAssCom.UseVisualStyleBackColor = false;
            this.buttonModAssCom.Click += new System.EventHandler(this.buttonModAssCom_Click);
            // 
            // tabPageCDMDP
            // 
            this.tabPageCDMDP.Controls.Add(this.panelChangerMDP);
            this.tabPageCDMDP.Location = new System.Drawing.Point(4, 33);
            this.tabPageCDMDP.Name = "tabPageCDMDP";
            this.tabPageCDMDP.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCDMDP.Size = new System.Drawing.Size(990, 462);
            this.tabPageCDMDP.TabIndex = 4;
            this.tabPageCDMDP.Text = "Changer de mot de passe";
            this.tabPageCDMDP.UseVisualStyleBackColor = true;
            // 
            // panelChangerMDP
            // 
            this.panelChangerMDP.BackColor = System.Drawing.Color.Transparent;
            this.panelChangerMDP.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.panelChangerMDP.Controls.Add(this.buttonValCDMDP);
            this.panelChangerMDP.Controls.Add(this.textBoxNoMDP);
            this.panelChangerMDP.Controls.Add(this.labelNoMDP);
            this.panelChangerMDP.Controls.Add(this.labelLogC);
            this.panelChangerMDP.Controls.Add(this.textBoxLog);
            this.panelChangerMDP.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChangerMDP.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelChangerMDP.Location = new System.Drawing.Point(3, 3);
            this.panelChangerMDP.Name = "panelChangerMDP";
            this.panelChangerMDP.Size = new System.Drawing.Size(984, 456);
            this.panelChangerMDP.TabIndex = 9;
            // 
            // buttonValCDMDP
            // 
            this.buttonValCDMDP.BackColor = System.Drawing.Color.Gold;
            this.buttonValCDMDP.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonValCDMDP.ForeColor = System.Drawing.Color.MidnightBlue;
            this.buttonValCDMDP.Location = new System.Drawing.Point(447, 212);
            this.buttonValCDMDP.Name = "buttonValCDMDP";
            this.buttonValCDMDP.Size = new System.Drawing.Size(90, 32);
            this.buttonValCDMDP.TabIndex = 18;
            this.buttonValCDMDP.Text = "Valider";
            this.buttonValCDMDP.UseVisualStyleBackColor = false;
            this.buttonValCDMDP.Click += new System.EventHandler(this.buttonValCDMDP_Click);
            // 
            // textBoxNoMDP
            // 
            this.textBoxNoMDP.Location = new System.Drawing.Point(440, 152);
            this.textBoxNoMDP.Name = "textBoxNoMDP";
            this.textBoxNoMDP.Size = new System.Drawing.Size(248, 27);
            this.textBoxNoMDP.TabIndex = 3;
            // 
            // labelNoMDP
            // 
            this.labelNoMDP.AutoSize = true;
            this.labelNoMDP.BackColor = System.Drawing.Color.Transparent;
            this.labelNoMDP.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNoMDP.Location = new System.Drawing.Point(258, 154);
            this.labelNoMDP.Name = "labelNoMDP";
            this.labelNoMDP.Size = new System.Drawing.Size(200, 21);
            this.labelNoMDP.TabIndex = 1;
            this.labelNoMDP.Text = "Nouveau mot de passe :";
            // 
            // labelLogC
            // 
            this.labelLogC.AutoSize = true;
            this.labelLogC.BackColor = System.Drawing.Color.Transparent;
            this.labelLogC.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogC.Location = new System.Drawing.Point(355, 96);
            this.labelLogC.Name = "labelLogC";
            this.labelLogC.Size = new System.Drawing.Size(59, 21);
            this.labelLogC.TabIndex = 0;
            this.labelLogC.Text = "Login :";
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(440, 94);
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.Size = new System.Drawing.Size(216, 27);
            this.textBoxLog.TabIndex = 2;
            // 
            // panelBordeLeft
            // 
            this.panelBordeLeft.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBordeLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelBordeLeft.Location = new System.Drawing.Point(0, 37);
            this.panelBordeLeft.Name = "panelBordeLeft";
            this.panelBordeLeft.Size = new System.Drawing.Size(1, 500);
            this.panelBordeLeft.TabIndex = 19;
            // 
            // panelBorderBottom
            // 
            this.panelBorderBottom.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBorderBottom.Location = new System.Drawing.Point(1, 536);
            this.panelBorderBottom.Name = "panelBorderBottom";
            this.panelBorderBottom.Size = new System.Drawing.Size(999, 1);
            this.panelBorderBottom.TabIndex = 20;
            // 
            // panelBorderRight
            // 
            this.panelBorderRight.BackColor = System.Drawing.Color.MidnightBlue;
            this.panelBorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelBorderRight.Location = new System.Drawing.Point(999, 37);
            this.panelBorderRight.Name = "panelBorderRight";
            this.panelBorderRight.Size = new System.Drawing.Size(1, 499);
            this.panelBorderRight.TabIndex = 21;
            // 
            // InterGes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Maquette_Belle_Table_Final.Properties.Resources.fond;
            this.ClientSize = new System.Drawing.Size(1000, 537);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.panelBorderRight);
            this.Controls.Add(this.panelBorderBottom);
            this.Controls.Add(this.panelBordeLeft);
            this.Controls.Add(this.tableLayoutEntete);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InterGes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InterGes";
            this.tableLayoutEntete.ResumeLayout(false);
            this.panelTitre.ResumeLayout(false);
            this.panelTitre.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBT)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPageCom.ResumeLayout(false);
            this.panelPlanning.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCom)).EndInit();
            this.tabPagePF.ResumeLayout(false);
            this.panelPF.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPF)).EndInit();
            this.tabPagePFI.ResumeLayout(false);
            this.panelPortefeuille.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPFI)).EndInit();
            this.tabPagePFC.ResumeLayout(false);
            this.panelPFC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPFC)).EndInit();
            this.tabPageCDMDP.ResumeLayout(false);
            this.panelChangerMDP.ResumeLayout(false);
            this.panelChangerMDP.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutEntete;
        private System.Windows.Forms.Panel panelTitre;
        private System.Windows.Forms.Label labelFermeture;
        private System.Windows.Forms.Label labelBT;
        private System.Windows.Forms.PictureBox pictureBoxBT;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageCom;
        private System.Windows.Forms.Panel panelPlanning;
        private System.Windows.Forms.DataGridView dataGridViewCom;
        private System.Windows.Forms.Button buttonVM;
        private System.Windows.Forms.Button buttonSupCom;
        private System.Windows.Forms.Button buttonModCom;
        private System.Windows.Forms.Button buttonAddCom;
        private System.Windows.Forms.Button buttonVRDV;
        private System.Windows.Forms.TabPage tabPagePF;
        private System.Windows.Forms.TabPage tabPagePFI;
        private System.Windows.Forms.Panel panelPortefeuille;
        private System.Windows.Forms.DataGridView dataGridViewPFI;
        private System.Windows.Forms.Button buttonModAssoInter;
        private System.Windows.Forms.TabPage tabPagePFC;
        private System.Windows.Forms.TabPage tabPageCDMDP;
        private System.Windows.Forms.Panel panelChangerMDP;
        private System.Windows.Forms.Button buttonValCDMDP;
        private System.Windows.Forms.TextBox textBoxNoMDP;
        private System.Windows.Forms.Label labelNoMDP;
        private System.Windows.Forms.Label labelLogC;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.Panel panelPF;
        private System.Windows.Forms.Button buttonCPF;
        private System.Windows.Forms.Button buttonSupPF;
        private System.Windows.Forms.Button buttonModPF;
        private System.Windows.Forms.Button buttonCrPF;
        private System.Windows.Forms.DataGridView dataGridViewPF;
        private System.Windows.Forms.Panel panelPFC;
        private System.Windows.Forms.DataGridView dataGridViewPFC;
        private System.Windows.Forms.Button buttonModAssCom;
        private System.Windows.Forms.Panel panelBordeLeft;
        private System.Windows.Forms.Panel panelBorderBottom;
        private System.Windows.Forms.Panel panelBorderRight;
    }
}